/******************************************************************************
 *
 * Copyright (c) 2000-2001 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: HostTransfer.h
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 * Description:
 *		Public include file for HostTransfer exchange library
 *
 * History:
 *   	1/7/00 Created by Danny Epstein
 *
 *****************************************************************************/

#ifndef __HOST_TRANSFER_H
#define __HOST_TRANSFER_H

#include <ExgLib.h>
#include <HostControl.h>	// for HOST_NAME_MAX
#include <SystemMgr.h>

// Name and creator of Host Transfer library. This name goes in the last slot of the dispatch
// table. It must match the name of the database, so that the Exchange Manager can map
// my creator ID to a reference number. It must have a creator ID suffix to conform to
// Palm OS naming conventions (to ensure uniqueness) and so that the Exchange Manaager
// can map my creator ID to a reference number on the simulator. 
#define HostTransferName				"HostTransfer Library-HXfr"
#define HostTransferCreator				'HXfr'	// registered creator ID

// URL scheme specifically for this exchange library
#define kHostTransferScheme				"_host"
#define kHostTransferPrefix				(kHostTransferScheme ":")

// Max length of host filenames + 1
#define kHostTransferFilenameBufferSize	(HOST_NAME_MAX + 1)

// Enum for operations in progress
#define kHostTransferOpNone				0
#define kHostTransferOpPut				1
#define kHostTransferOpAccept			2
#define kHostTransferOpGet				3
typedef UInt8 HostTransferOpType;

// Structure pointed to by ExgSocketType.socketRef
typedef struct {
	HostFILEType *hostFileP;
	Boolean freeOnDisconnect;	// whether to free this struct when the operation completes
	HostTransferOpType op;		// operation in progress, if any
	Char filename[kHostTransferFilenameBufferSize];	// edited filename is stored here
} HostTransferSocketInfoType;	


/************************************************************
 * Library procedures.
 *************************************************************/ 
#pragma mark Functions
#ifdef __cplusplus
extern "C" {
#endif

#if EMULATION_LEVEL != EMULATION_NONE
// Private entrypoint used by simulator to install library
Err	PrvInstallHostTransferDispatcher(UInt16 refNum, SysLibTblEntryType *entryP);
#endif

Err HostTransferLibOpen(UInt16 refNum);
Err HostTransferLibClose(UInt16 refNum);
Err HostTransferLibWake(UInt16 refNum);
Err HostTransferLibSleep(UInt16 refNum);
Boolean HostTransferLibHandleEvent(UInt16 refNum, void *eventP);
Err HostTransferLibConnect(UInt16 refNum, ExgSocketType *socketP);
Err HostTransferLibGet(UInt16 refNum, ExgSocketType *socketP);
Err HostTransferLibPut(UInt16 refNum, ExgSocketType *socketP);
Err HostTransferLibAccept(UInt16 refNum, ExgSocketType *socketP);
Err HostTransferLibDisconnect(UInt16 refNum, ExgSocketType *socketP, Err appError);
UInt32 HostTransferLibSend(UInt16 refNum, ExgSocketType *socketP,
	const void *bufP, UInt32 bufLen, Err* errP);
UInt32 HostTransferLibReceive(UInt16 refNum, ExgSocketType *socketP,
	void *bufP, UInt32 bufSize, Err *errP);
Err HostTransferLibControl(UInt16 refNum, UInt16 op, void *valueP, UInt16 *valueLenP);
Err HostTransferLibRequest(UInt16 refNum, ExgSocketType *socketP);

#ifdef __cplusplus
}
#endif

#endif  // __HOST_TRANSFER_H
