/******************************************************************************
 *
 * Copyright (c) 2000-2001 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: HostTransferPrv.h
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 * Description:
 *		Private include file for the HostTransfer exchange library.
 *
 * History:
 *   	1/7/00  Created by Danny Epstein from Gavin's sample
 *
 *****************************************************************************/

#ifndef __HOST_TRANSFER_PRV_H
#define __HOST_TRANSFER_PRV_H

#include <Progress.h>
#include "HostTransfer.h"


// We require PalmOS 4.0.
#define kVersion4_0				0x04000000


// Stages of a connection. Used by the protocol task to inform the UI task
// what stage we're on during connection establishment. Many of these aren't
// actually used.
typedef enum
	{
	kHostTransferConStageInvalid,							// invalid stage 
	kHostTransferConStageInactive,						// not started.
	kHostTransferConStageConnected,						// connected
	kHostTransferConStageSending,							// sending data
	kHostTransferConStageReceiving,						// receiving data
	kHostTransferConStageDisconnecting					// disconnecting
	} HostTransferConStageEnum;

#define	kHostTransferStrIndexCancelling			2				// "Cancelling"
#define	kHostTransferStrIndexError					3				// "Error: "
#define	kHostTransferStrIndexInitializing		4				// "Initializing"
#define	kHostTransferStrIndexStarting				5				// "Starting"
#define	kHostTransferStrIndexSearching			6				// "Searching"
#define	kHostTransferStrIndexConnected			7				// "Connected"
#define	kHostTransferStrIndexSending				8				// "Sending: "
#define	kHostTransferStrIndexReceiving			9				// "Receiving: "
#define	kHostTransferStrIndexDisconnecting		10				// "Disconnecting"
#define	kHostTransferStrIndexWaitingSender		11				// "Waiting for Sender"
#define	kHostTransferStrIndexPreparing			12				// "Preparing"
#define	kHostTransferStrIndexAccepting			13				// "Accepting"
#define	kHostTransferStrIndexInterrupted			14				// "Transfer Interrupted"



// Global data structure for this library
typedef struct
	{
	UInt16 refNum;								// this lib's refnum
	Int16 openCount;			 				// how many times I've been opened	
	ProgressType *prgP;						// progress dialog globals
	HostTransferConStageEnum curStage;	// current stage
	DmOpenRef resourceDBP;					// this library's resources
	} HostTransferGlobalsType;


extern Err PrvInstallHostTransferDispatcher(UInt16 refNum, SysLibTblEntryType *entryP);
extern void *PrvHostTransferDispatchTable(void);
extern void PrvDeleteExistingMacro(const Char *nameP);

#endif // __HOST_TRANSFER_PRV_H