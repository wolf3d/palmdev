/******************************************************************************
 *
 * Copyright (c) 2000-2001 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: HostTransferDispatch.c
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 * Description:
 *              Dispatch table for the HostTransfer exchange library. This module
 *		gets linked in with the library source modules. It provides the library
 *		dispatch table and the routine for initializing this table when the
 *		library is installed.
 *
 * History:
 *   	1/7/00  Created by Danny Epstein
 *
 *****************************************************************************/

// Define this so we don't use the Pilot pre-compiled headers.
// We can't use them here because we re-define some build options
#ifndef PILOT_PRECOMPILED_HEADERS_OFF
#define PILOT_PRECOMPILED_HEADERS_OFF
#endif

// Define this so that we can get the addresses of the Serial Library
// routines. Other modules access the routines through traps. This is
// needed so that we can fill in the dispatch table with the addresses
// of the actual routines.
#define USE_TRAPS 0


#include "HostTransfer.h"

void *PrvHostTransferDispatchTable(void);

#if 0
extern Err PrvInstallHostTransferDispatcher(UInt16 refNum, SysLibTblEntryType *entryP);


/***********************************************************************
 *
 *  FUNCTION:     __Startup__
 *
 *  DESCRIPTION:  Entry point for Library installation resource. This
 *						is a 'libr' resource in the HostTransfer resource database.
 *						This resource contains the HostTransfer Library API entry points. 
 *						
 *						To install the library, the system gets a pointer to this
 *						resource and passes it to SysLibInstall(). SysLibInstall() will
 *						jump to this resource to have it install it's dispatch table
 *						into the library entry. 
 *
 *  PARAMETERS:   
 *					refNum - refNum of library
 *					entryP - pointer to entry in library table.
 *
 *  RETURNS:   	0 if no error   
 *
 *  CALLED BY:    SysLibInstall()
 *
 *  CREATED:      1/7/00
 *
 *  BY:           Danny Epstein
 *
 ***********************************************************************/
#if EMULATION_LEVEL == EMULATION_NONE
Err __Startup__(UInt16 refNum, SysLibTblEntryType *entryP)
{
	return PrvInstallHostTransferDispatcher(refNum, entryP);
}
#endif

#endif

/************************************************************
 *
 *  FUNCTION: Dispatch Table for HostTransfer Library
 *
 *  DESCRIPTION: This table gets installed into the dispatchTblP
 *		field of the library entry in the library table. It gives
 *		the 16-bit offset of every routine relative to the start of
 *		the dispatch table.
 *
 *		This is a dummy dispatch table for the simulator, it is only 
 *		used to retrieve the name of the library. Library functions
 *		are called directly by the simulator so we do not need a table.
 *
 * REVISION HISTORY:
 *************************************************************/
#define	kNumDispatchEntries	14					// UPDATE THIS WHEN CALLS ARE ADDED TO @TABLE
#define	kOffset					((kNumDispatchEntries + 1) * 2)

#if EMULATION_LEVEL == EMULATION_NONE
#if defined(__MC68K__)
asm void *PrvHostTransferDispatchTable(void)
{
	LEA		@Table, A0								// table ptr
	RTS													// exit with it

@Table:
	DC.W		@Name
	DC.W		(kOffset)								// Open
	DC.W		(kOffset+(1*4))						// Close
	DC.W		(kOffset+(2*4))						// Sleep
	DC.W		(kOffset+(3*4))						// Wake
	
	// Start of the exchange libary
	DC.W		(kOffset+(4*4))						// HostTransferLibHandleEvent
	DC.W		(kOffset+(5*4))						// HostTransferLibConnect
	DC.W		(kOffset+(6*4))						// HostTransferLibAccept
	DC.W		(kOffset+(7*4))						// HostTransferLibDisconnect
	DC.W		(kOffset+(8*4))						// HostTransferLibPut
	DC.W		(kOffset+(9*4))						// HostTransferLibGet
	DC.W		(kOffset+(10*4))						// HostTransferLibSend
	DC.W		(kOffset+(11*4))						// HostTransferLibReceive
	DC.W		(kOffset+(12*4))						// HostTransferLibControl
	DC.W		(kOffset+(13*4))						// HostTransferLibRequest


@GotoOpen:
	JMP 		HostTransferLibOpen
@GotoClose:
	JMP 		HostTransferLibClose
@GotoSleep:
	JMP 		HostTransferLibSleep
@GotoWake:
	JMP 		HostTransferLibWake


@GotoHandleEvent:
	JMP 		HostTransferLibHandleEvent
@GotoConnect:
	JMP 		HostTransferLibConnect
@GotoAccept:
	JMP 		HostTransferLibAccept
@GotoDisconnect:
	JMP 		HostTransferLibDisconnect
@GotoPut:
	JMP 		HostTransferLibPut
@GotoGet:
	JMP 		HostTransferLibGet
@GotoSend:
	JMP 		HostTransferLibSend
@GotoReceive:
	JMP 		HostTransferLibReceive
@GotoOption:
	JMP 		HostTransferLibControl
@GotoCheck:
	JMP 		HostTransferLibRequest

@Name:
	DC.B		HostTransferName

}
#else
#error "Processor type not defined"
#endif

#else	// EMULATION_LEVEL == EMULATION_NONE

static const void *dispatchTable[] =
{
	// Number of entries that follow (not counting the name entry after)
	(void*)kNumDispatchEntries,
	
	// Common to all libraries
	HostTransferLibOpen,
	HostTransferLibClose,
	HostTransferLibSleep,
	HostTransferLibWake,
	
	// Exchange lib common...
	HostTransferLibHandleEvent,
	HostTransferLibConnect,
	HostTransferLibAccept,
	HostTransferLibDisconnect,
	HostTransferLibPut,
	HostTransferLibGet,
	HostTransferLibSend,
	HostTransferLibReceive,
	HostTransferLibControl,
	HostTransferLibRequest,
	
	// The library name
	HostTransferName
};

void *PrvHostTransferDispatchTable(void)
{
	return (void *)&dispatchTable;
}
#endif	// EMULATION_LEVEL == EMULATION_NONE
