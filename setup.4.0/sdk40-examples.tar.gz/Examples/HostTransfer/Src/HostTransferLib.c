/******************************************************************************
 *
 * Copyright (c) 2000-2001 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: HostTransferLib.c
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 * Description:
 *		This sample exchange library uses the Host API of the emulator
 *		and Mac simulator to read and write files on the desktop.
 *
 * History:
 *   	1/6/00  Created by Danny Epstein from Gavin's sample
 *
 *****************************************************************************/

#include <Chars.h>
#include <ErrorMgr.h>
#include <ExgMgr.h>
#include <FeatureMgr.h>
#include <Graffiti.h>
#include <HostControl.h>
#include <Progress.h>
#include <SoundMgr.h>
#include <StringMgr.h>
#include <SysEvtMgr.h>
#include <SysUtils.h>
#include <TextMgr.h>
#include <TimeMgr.h>
#include <UIResources.h>
#include "HostTransferPrv.h"
#include "HostTransferLib_res.h"


// Private constants.
#define kInboxDirectoryFilename		"inbox.dir"


// External functions referenced without header file declarations.
extern void *PrvHostTransferDispatchTable(void);	// extern ref from dispatcher


// Private functions.
static Boolean PrvTextCallback(PrgCallbackData *cbP);
static HostTransferGlobalsType *PrvGetGlobals(UInt16 refNum);
static Err PrvProcessEvents(HostTransferGlobalsType *gP, UInt16 timeout);
static void PrvStartDialog(HostTransferGlobalsType *gP);
static Err PrvCleanUp(HostTransferGlobalsType *gP, ExgSocketType *socketP);
static Boolean PrvDoSendDialog(ExgSocketType *socketP, Char *filenameP, Err *errP);


/***********************************************************************
 *
 * FUNCTION:     PrvDeleteExistingMacro
 *
 * DESCRIPTION:  Delete any existing macro with the given name.
 *
 * PARAMETERS:
 *		nameP		- macro name to check
 *
 * RETURNS: nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			dje		11/14/00	Initial Revision based on PrvMacroAlreadyExists
 *
 ***********************************************************************/
void PrvDeleteExistingMacro(const Char *nameP)
{
	Err grfError = errNone;
	Char nextName[grfNameLength + 1];
	Boolean match = false;
	UInt16 index;
	
	// for each name that Graffiti knows
	for (index = 0; grfError == errNone; index++)
		{
		//  get the next name from Graffiti
		grfError = GrfGetMacroName(index, nextName);
		if (grfError) break;		// error ignored
		
		match = (StrCompare(nextName, nameP) == 0);
		if (match)
			{
			GrfDeleteMacro(index);	// there can only be one macro with a given name
			break;
			}
		}
}


/************************************************************
 *
 *  FUNCTION: PrvInstallHostTransferDispatcher
 *
 *  DESCRIPTION: This is the entry point to the exchange library
 *		It gets called by the System when installing the library.
 *    In the mac simulator, you must call this directly from the app
 *		that will use the library.
 *
 *		This routine must install the library's dispatch table into the
 *		library entry pointer.
 *
 *  PARAMETERS:
 *		refNum		- refNum of library
 *		entryP		- entry in system's library table where we keep our global pointer
 *
 *  CALLED BY:
 *    Called from library startup routine.
 *		Called directly by simulator when installing library for testing on the Mac.
 *		Note that unless you change the name, only one library can be installed
 *    in the mac simulator this way.
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
#define	PrvHexToAscii(x)	((x) > 9 ? (x)-10+'A' : (x)+'0')

Err PrvInstallHostTransferDispatcher(UInt16 refNum, SysLibTblEntryType *entryP)
{
	Err err;
	HostTransferGlobalsType *gP;
	UInt32 value;
	Char macro[14];
	
	// Must be 4.0 or greator
	err = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &value);
	if (err || value < kVersion4_0) return -1;
	
	// Allocate library globals and store pointer to them in system's library table
	gP = MemPtrNew(sizeof(HostTransferGlobalsType));
	ErrFatalDisplayIf(!gP, "No memory for globals");
	if (gP)
		{
		MemPtrSetOwner(gP, 0);
		MemSet(gP, sizeof(HostTransferGlobalsType), 0);
		gP->refNum = refNum;		// make self reference
		entryP->globalsP = gP;
		}

	// Install pointer to our dispatch table in system's library table
	entryP->dispatchTblP = (MemPtr *)PrvHostTransferDispatchTable();
	
	// Check if we're running on the simulator or emulator. On a real device,
	// there's no host so we don't register this library with the Exchange
	// Manager. In this case, we should really abort the library installation
	// altogether, but this demonstrates how exchange libs can change their
	// registration status.
#if EMULATION_LEVEL == EMULATION_NONE
	if (FtrGet('pose', 0, &value) != ftrErrNoSuchFeature)
#endif
		{
		Char description[exgTitleBufferSize + 1];
		UInt16 descriptionSize = sizeof(description);
		Err err;
		
		// Get the title of the library
		err = HostTransferLibControl(refNum, exgLibCtlGetTitle, &description, &descriptionSize);
		if (! err)
			{
			// Register this library with the Exchange Manager
			err = ExgRegisterDatatype(HostTransferCreator, exgRegSchemeID,
				kHostTransferScheme "\t" exgSendScheme, description, 0 /*flags*/);
			}
		}
	
	// Add a magic macro to initiate ExgRequest
	StrCopy(macro, "\x01" "0117" "0000" "0408");
	// virtualkeycode,vchrIrReceive,refnum,libEvtHookKeyMask
	macro[7] = PrvHexToAscii((refNum>>4) & 0x0f);	// stuff refnum into string as hex
	macro[8] = PrvHexToAscii(refNum & 0x0f);
	PrvDeleteExistingMacro(".r");
	GrfAddMacro(".r", (UInt8 *)macro, 13);
	
	return err;
}


/************************************************************
 *
 * FUNCTION:	HostTransferLibOpen
 *
 * DESCRIPTION:	Opens the resource database so we can find our
 *				resources. We keep the database open until the
 *				Disconnect so applications can't use another
 *				shared library that keeps databases open at
 *				the same time.
 *
 * PARAMETERS:
 *		refNum		 	- refNum of the library
 *
 * CALLED BY:
 *		ExgLibRequest, ExgLibPut, ExgLibRequest.
 *		Applications shouldn't need to call this function.
 *
 * RETURNS:	0 if no error
 *
 * CREATED:	1/6/00
 *
 * BY:		Danny Epstein
 *
 *************************************************************/
Err HostTransferLibOpen(UInt16 refNum)
{
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	
	if (!gP->resourceDBP)
	{			
		// Open the application/library's database, so we can use it's resources
		// note that resources used here must NOT overlap with application resources!!!
#if EMULATION_LEVEL == EMULATION_NONE
		gP->resourceDBP = DmOpenDatabaseByTypeCreator(sysFileTApplication, HostTransferCreator, dmModeReadOnly);
		ErrNonFatalDisplayIf(!gP->resourceDBP, "Error opening resource database");
#endif
	}
	gP->openCount++;
	
	return 0;
	
}


/************************************************************
 *
 * FUNCTION:	HostTransferLibClose
 *
 * DESCRIPTION:	Close the resource database.
 *
 * PARAMETERS:
 *		refNum		 	- refNum of the library
 *
 * CALLED BY:
 *		ExgLibRequest, ExgLibDisconnect.
 *		Applications shouldn't need to call this function.
 *
 * RETURNS:	0 or error code
 *
 * CREATED:	1/6/00
 *
 * BY:		Danny Epstein
 *
 *************************************************************/
Err HostTransferLibClose(UInt16 refNum)
{
	Err err = 0;
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	
	// Close dialog.
	if (gP->prgP)
		{
		PrgStopDialog(gP->prgP, false);
		gP->curStage = kHostTransferConStageInvalid;
		gP->prgP = 0;
		}
	
	if (gP->openCount == 1)
		{
		// Close the application/library's database
		if (gP->resourceDBP)
			{	
			err = DmCloseDatabase(gP->resourceDBP);
			gP->resourceDBP = 0;
			ErrNonFatalDisplayIf(err, "Error closing resource database");
			}
		}
	gP->openCount--;
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibWake
 *
 *  DESCRIPTION: Called by the system before it wakes up
 *
 *  CALLED BY:	 HwrSleep()
 *
 *  PARAMETERS:  nothing
 *
 *  RETURNED:    nothing
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *  BY: Gavin Peacock
 *
 *************************************************************/
Err HostTransferLibWake(UInt16 refNum)
{
	return 0;
}

/************************************************************
 *
 *  FUNCTION: HostTransferLibSleep
 *
 *  DESCRIPTION: Called by the system before it goes to sleep
 *
 *  CALLED BY:	 HwrSleep()
 *
 *  PARAMETERS:  nothing
 *
 *  RETURNED:    nothing
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
Err HostTransferLibSleep(UInt16 refNum)
{
	return 0;
}


/************************************************************
 *
 * FUNCTION: PrvNotifyApp
 *
 * DESCRIPTION: Utility routine to notify applications about
 *				files in the inbox.
 *
 * PARAMETERS: 
 *				refnum - library refnum
 *				filename - name of file in inbox
 * 
 * RETURNS: 0 if no error
 *
 * CREATED: 1/7/00
 *
 * BY: Danny Epstein
 *
 *************************************************************/
static Err PrvNotifyApp(UInt16 refNum, char *filename)
{
	Err err = 0;
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	ExgSocketType *newSockP = NULL;
	HostTransferSocketInfoType *newSocketInfoP = NULL;
	
	newSockP = MemPtrNew(sizeof(ExgSocketType));
	newSocketInfoP = MemPtrNew(sizeof(HostTransferSocketInfoType));
	if (!newSockP || !newSocketInfoP)
		{
		err = exgMemError;
		goto Exit;
		}
	MemPtrSetOwner(newSockP, 0);
	MemPtrSetOwner(newSocketInfoP, 0);
	MemSet(newSockP, sizeof(ExgSocketType), 0);
	newSockP->libraryRef = refNum;
	newSockP->socketRef = (UInt32)newSocketInfoP;
	newSocketInfoP->freeOnDisconnect = false;
	newSocketInfoP->hostFileP = NULL; 		// file not open yet
	newSocketInfoP->op = kHostTransferOpNone;	// app hasn't called ExgAccept yet
	StrCopy(newSocketInfoP->filename, filename);
	newSockP->name = newSocketInfoP->filename;	// make name point into socket info struct
	//newSockP->noAsk = true;	// don't send askUser launch code or put up dialog
	//newSockP->noGoTo = true;	// skip goto launch
	
	err = ExgNotifyReceive(newSockP, 0 /*flags*/);
	if (! err)
		err = ExgNotifyGoto(newSockP, 0 /*flags*/);
	
	if (err && err != exgErrUserCancel)
		{
		// Dialog may have already been closed; reopen to show error.
		PrvStartDialog(gP);
		PrgUpdateDialog(gP->prgP, err, gP->curStage, 0, true);
		}
	
Exit:
	if (newSockP)
		MemPtrFree(newSockP);
	if (newSocketInfoP)
		MemPtrFree(newSocketInfoP);
	return err;
}


/************************************************************
 *
 * FUNCTION:	HostTransferLibRequest
 *
 * DESCRIPTION: Check the inbox for files to import. Notify the appropriate
 *				application for each file. Don't goto any of them.
 *
 * CALLED BY:   Applications when user chooses "Check" button or similar.
 *				This is a new API in all exchange libraries.
 *
 * PARAMETERS:
 *				refNum		- refNum of the library
 *				socketP		- socket specifying what to check - not used
 *
 * RETURNED:    error code
 *
 * CREATED:		1/6/00
 *
 * BY:			Danny Epstein
 *
 *************************************************************/
Err HostTransferLibRequest(UInt16 refNum, ExgSocketType *socketP)
{
#pragma unused (socketP)
	// DOLATER dje - Change to use the directory APIs in HostControl once they're available
	//			in the simulator. Code for this is commented out below.
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	HostFILEType *indexFileP, *fileP;
	// HostDIRType *dirP;
	// HostDirEntType *entryP;
	Err err = 0;
	char filename[kHostTransferFilenameBufferSize];		// the current file in the inbox
	
	err = HostTransferLibOpen(refNum);
	if (err)
		return err;
	
	// Open the inbox directory file.
	indexFileP = HostFOpen(kInboxDirectoryFilename, "r");
	if (indexFileP)
		{
		// Look for all files listed in inbox directory file.
		while (!err && HostFGetS(filename, kHostTransferFilenameBufferSize, indexFileP))
			{
			filename[kHostTransferFilenameBufferSize - 1] = chrNull;
			if (filename[StrLen(filename) - 1] == '\n')
				filename[StrLen(filename) - 1] = chrNull;
			
			// Try to open the file just to make sure it exists.
			fileP = HostFOpen(filename, "rb");
			if (! fileP)
				{
				err = exgErrNotFound;
				PrvStartDialog(gP);	// Dialog may have already been closed; reopen to show error.
				PrgUpdateDialog(gP->prgP, err, gP->curStage, 0, true);
				}
			else
				{
				HostFClose(fileP);
				err = PrvNotifyApp(refNum, filename);
				}
			}
		HostFClose(indexFileP);
		}
	else
		{
		// No inbox directory file exists, so prompt the user for a single file to read.
		if (FrmCustomResponseAlert(FilenameAlert, NULL, NULL, NULL,
			filename, kHostTransferFilenameBufferSize, NULL) == FilenameOK)
			{
			// Try to open the file just to make sure it exists.
			fileP = HostFOpen(filename, "rb");
			if (! fileP)
				{
				err = exgErrNotFound;
				PrvStartDialog(gP);	// Dialog may have already been closed; reopen to show error.
				PrgUpdateDialog(gP->prgP, err, gP->curStage, 0, true);
				}
			else
				{
				HostFClose(fileP);
				err = PrvNotifyApp(refNum, filename);
				}
			}
		else
			err = exgErrUserCancel;
	}
	
	/* Experimental code to use the new directory HostControl APIs.
	// Prompt the user for a directory or file to read.
	if (FrmCustomResponseAlert(FilenameAlert, NULL, NULL, NULL,
		filename, kHostTransferFilenameBufferSize, NULL) == FilenameOK)
		{ // Try to open as directory.
		dirP = HostOpenDir(filename);
		if (dirP)
			{ // Read directory contents.
			while (! err)
				{
				entryP = HostReadDir(dirP);
				if (entryP)
					{ // Open each file (to make sure it's a file rather than a directory).
					fileP = HostFOpen(entryP->d_name, "rb");
					if (fileP)
						{ // Deliver each file.
						HostFClose(fileP);
						err = PrvNotifyApp(refNum, filename);
						}
					else
						{ // Dialog may have already been closed; reopen to show error.
						err = exgErrNotFound;
						PrvStartDialog(gP);
						PrgUpdateDialog(gP->prgP, err, gP->curStage, 0, true);
						}
					}
				else
					break;
				}
			err = HostCloseDir(dirP);
			}
		else
			{ // Try to open as file.
			fileP = HostFOpen(filename, "rb");
			if (fileP)
				{ // Deliver the one file.
				HostFClose(fileP);
				err = PrvNotifyApp(refNum, filename);
				}
			else
				{ // Dialog may have already been closed; reopen to show error.
				err = exgErrNotFound;
				PrvStartDialog(gP);
				PrgUpdateDialog(gP->prgP, err, gP->curStage, 0, true);
				}
			}
		}
	else
		err = exgErrUserCancel; */

	if (err && gP->prgP)
		PrgUpdateDialog(gP->prgP, err, kHostTransferConStageDisconnecting, 0, true);
	PrvCleanUp(gP, NULL);  
	
	HostTransferLibClose(refNum);
	
	return err;
}


/************************************************************
 *
 * FUNCTION:	HostTransferLibHandleEvent
 *
 * DESCRIPTION: Called by the SysHandleEvent on event hook keys.
 *				This entrypoint MUST come immediatly after HostTransferLibSleep
 *				in the library trap table!
 *
 * CALLED BY:	SysHandleEvent and EvtGetSysEvent. Also called directly 
 *				by the library in some places.
 *
 * PARAMETERS:
 *				refNum - library reference number
 *				eventP - pointer to the event
 *
 * RESULT:		true if event was handled
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			dje		1/6/00		Created.
 *
 *************************************************************/
Boolean HostTransferLibHandleEvent(UInt16 refNum, void *eventP)
{
	Err err = 0;
	EventType *evP = (EventType *)eventP;		// cast back to event
	
	// Ignore everything but special evt key events for this library.
	if ( !(	(evP->eType == keyDownEvent) &&
			(evP->data.keyDown.modifiers & libEvtHookKeyMask) &&
			(evP->data.keyDown.keyCode == refNum) ) )
		return false;
	
	if (evP->data.keyDown.chr == vchrIrReceive)
		HostTransferLibRequest(refNum, NULL);
	
	// We don't actually handle any events.
	
	return true;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibConnect
 *
 *  DESCRIPTION: Establish an exchange connection
 *
 *  CALLED BY:
 *
 *  PARAMETERS:
 *				refNum - library reference number
 *				socketP - pointer to the exgSocket
 *
 *	 RESULT:		non zero error code if error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
Err HostTransferLibConnect(UInt16 refNum, ExgSocketType *socketP)
{
	// Not supported.
	return 0;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibGet
 *
 *  DESCRIPTION: request data with a GET transaction
 *
 *  CALLED BY:
 *
 *  PARAMETERS:
 *				refNum - library reference number
 *				socketP - pointer to the exgSocket
 *
 *	 RESULT:		non zero error code if error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
Err HostTransferLibGet(UInt16 refNum, ExgSocketType *socketP)
{
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	Err err = 0;
	Char *name;
	UInt16 nameLen;
	char filename[kHostTransferFilenameBufferSize];		// the current file in the inbox
	HostTransferSocketInfoType *socketInfoP;
	
	
	err = HostTransferLibOpen(refNum);
	if (err)
		return err;
	
	// Show dialog and setup callback for status text.
	PrvStartDialog(gP);
	
	socketInfoP = (HostTransferSocketInfoType *)socketP->socketRef;
	if (!socketInfoP)
		{
		// Allocate a struct to store the filename and operation.
		socketInfoP = MemPtrNew(sizeof(HostTransferSocketInfoType));
		if (socketInfoP)
			{
			MemPtrSetOwner(socketInfoP, 0);
			socketInfoP->freeOnDisconnect = true;
			socketP->socketRef = (UInt32)socketInfoP;
			}
		else
			err = exgMemError;
		}

	// Set up field block with current filename
	if (socketP->name && *socketP->name)
		{
		name = StrChr(socketP->name, chrColon);  // strip out the prefix
		if (name)
			name++;
		else
			name = socketP->name;
		nameLen = StrLen(name) + 1;
		}
	else
		nameLen = 0;
	
	if (!nameLen)
		{// No name passed in, so prompt the user for a single file
		if (FrmCustomResponseAlert(FilenameAlert, NULL, NULL, NULL,
			filename, kHostTransferFilenameBufferSize, NULL) == FilenameOK)
			{
			name = filename;
			nameLen = StrLen(name);
			}
		}
		
	if (nameLen)	
		{
		// Try to open the file just to make sure it exists.
		
		socketInfoP->op = kHostTransferOpGet;
		socketInfoP->hostFileP = HostFOpen(name, "rb");
		if (! socketInfoP->hostFileP)
			{
			err = exgErrNotFound;
			PrgUpdateDialog(gP->prgP, err, gP->curStage, 0, true);
			}
		}
	else
		err = exgErrNotFound;
	
	if (err && gP->prgP)
		PrgUpdateDialog(gP->prgP, err, kHostTransferConStageDisconnecting, 0, true);

	if (err)
		PrvCleanUp(gP, socketP);
	else
		err = PrvProcessEvents(gP, 0);
		
	return err;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibPut
 *
 *  DESCRIPTION: Starts a Put operation. The socket data
 *		contains both the connection information and the info
 *		about the object to be sent. If a connection does not
 *		already exist, then this will establish one.
 *
 *  PARAMETERS:
 *		refNum		 	-> library reference number
 *		socketP			-> pointer to exg socket data
 *
 *	 CALLED BY:
 *		Whoever wants to start an Put transaction
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
Err HostTransferLibPut(UInt16 refNum, ExgSocketType *socketP)
{
	Err err = 0;
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	HostTransferSocketInfoType *socketInfoP;
	Char filename[kHostTransferFilenameBufferSize];
	
	err = HostTransferLibOpen(refNum);
	if (err) return err;
	
	if (PrvDoSendDialog(socketP, filename, &err) && !err)
	{
		// Show dialog and setup callback for status text.
		PrvStartDialog(gP);
		
		socketInfoP = (HostTransferSocketInfoType *)socketP->socketRef;
		if (!socketInfoP)
			{
			// Allocate a struct to store the filename and operation.
			socketInfoP = MemPtrNew(sizeof(HostTransferSocketInfoType));
			if (socketInfoP)
				{
				MemPtrSetOwner(socketInfoP, 0);
				socketInfoP->freeOnDisconnect = true;
				socketP->socketRef = (UInt32)socketInfoP;
				}
			else
				err = exgMemError;
			}
		
		// Update the progress dialog
		gP->curStage = kHostTransferConStageSending;	
		PrgUpdateDialog(gP->prgP, err, gP->curStage, socketP->description, true);
		
		// Open the file.
		if (!err)
			{
			socketInfoP->op = kHostTransferOpPut;
			StrCopy(socketInfoP->filename, filename);
			socketInfoP->hostFileP = HostFOpen(filename, "wb");
			if (!socketInfoP->hostFileP)
				err = exgErrUnknown;
			}
		
		// Close dialog on error.
		if (err)
			PrvCleanUp(gP, socketP);
		else
			err = PrvProcessEvents(gP, 0);
	}
	else
		HostTransferLibClose(refNum);
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibAccept
 *
 *  DESCRIPTION: Accepts an incoming connection
 *
 *  PARAMETERS:
 *		refNum		 	-> library reference number
 *		socketP			-> pointer to exg socket data
 *
 *	 CALLED BY:
 *		Whoever wants to accept an Exchange connection
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
Err HostTransferLibAccept(UInt16 refNum, ExgSocketType *socketP)
{
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	Err err = 0;
	char filename[kHostTransferFilenameBufferSize];
	HostTransferSocketInfoType *socketInfoP;
	
	if (socketP->preview)
		return exgErrNotSupported;	// DOLATER dje - support preview
	
	err = HostTransferLibOpen(refNum);
	if (err) return err;
	
	// Show dialog.
	PrvStartDialog(gP);
	
	socketInfoP = (HostTransferSocketInfoType *)socketP->socketRef;
	if (!socketInfoP)
		{
		// Allocate a struct to store the filename and operation.
		socketInfoP = MemPtrNew(sizeof(HostTransferSocketInfoType));
		if (socketInfoP)
			{
			MemPtrSetOwner(socketInfoP, 0);
			socketInfoP->freeOnDisconnect = true;
			socketP->socketRef = (UInt32)socketInfoP;
			}
		else
			err = exgMemError;
		}
	
	// Update the progress dialog.
	gP->curStage = kHostTransferConStageReceiving;
	PrgUpdateDialog(gP->prgP, err, gP->curStage, socketP->description, false);
	
	// Open the file in the inbox.
	if (!err)
		{
		socketInfoP->op = kHostTransferOpAccept;
		StrNCopy(filename, socketP->name, kHostTransferFilenameBufferSize);
		filename[kHostTransferFilenameBufferSize - 1] = chrNull;
		if (filename[StrLen(filename) - 1] == '\n')
			filename[StrLen(filename) - 1] = chrNull;
		socketInfoP->hostFileP = HostFOpen(filename, "rb");
		if (!socketInfoP->hostFileP)
			err = exgErrUnknown;
		}
	
	// Close dialog on error.
	if (err)
		PrvCleanUp(gP, socketP);
	else
		err = PrvProcessEvents(gP, 0);
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibDisconnect
 *
 *  DESCRIPTION: Closes an Exchange session releasing all library
 *					memory.
 *
 *  PARAMETERS:
 *		refNum		 	-> library reference number
 *		socketP			-> pointer to exg socket data
 *		appError			-> application error code
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
Err HostTransferLibDisconnect(UInt16 refNum, ExgSocketType *socketP, Err appError)
{
	Err err = appError;
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	
	// Show error message in dialog.
	if (err && gP->prgP)
		{
		PrgUpdateDialog(gP->prgP, err, kHostTransferConStageDisconnecting, 0, true);
		}
	
	// Clean things up
	PrvCleanUp(gP, socketP);

	HostTransferLibClose(refNum);
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibSend
 *
 *  DESCRIPTION: Sends data over an Exchange connection
 *
 *  PARAMETERS:
 *		refNum		 	-> library reference number
 *		socketP			-> pointer to exg socket data
 *
 *  CALLED BY:
 *		Whoever wants to send Exchange data
 *
 *  RETURNS: number of bytes written or 0 on error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
UInt32 HostTransferLibSend(UInt16 refNum, ExgSocketType *socketP,
	const void *bufP, UInt32 bufLen, Err* errP)
{
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	long charsWritten;
	HostTransferSocketInfoType *socketInfoP;
	
	*errP = 0;
	
	socketInfoP = (HostTransferSocketInfoType *)socketP->socketRef;
	ErrNonFatalDisplayIf(!socketInfoP, "must call ExgPut first");
	ErrNonFatalDisplayIf(socketInfoP->op != kHostTransferOpPut, "must call ExgPut first");
	ErrNonFatalDisplayIf(!socketInfoP->hostFileP, "host file not open");
	
	if (gP->curStage != kHostTransferConStageSending)	
		{
		gP->curStage = kHostTransferConStageSending;	
		PrgUpdateDialog(gP->prgP, *errP, gP->curStage, socketP->description, true);
		}
	
	*errP = PrvProcessEvents(gP, 0);
	
	if (PrgUserCancel(gP->prgP))
		{
		*errP = exgErrUserCancel;
		return 0;
		}
	
	// Write the data to the file (all or nothing).
	charsWritten = HostFWrite(bufP, sizeof(char), bufLen, socketInfoP->hostFileP);
	if (charsWritten < bufLen)
		{
		*errP = exgErrUnknown;
		return 0;
		}
	return charsWritten;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibReceive
 *
 *  DESCRIPTION: Starts an Exchange receive
 *
 *  PARAMETERS:
 *		refNum		 	-> library reference number
 *		socketP			-> pointer to exg socket data
 *		bufP				-> pointer to buffer to put incoming data in
 *		bufSize			-> size of buffer
 *		errP				-> pointer to returned error code
 *
 *  CALLED BY:
 *		Whoever wants to receive Exchange data.
 *
 *  RETURNS: number of bytes read
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
UInt32 HostTransferLibReceive(UInt16 refNum, ExgSocketType *socketP,
	void *bufP, UInt32 bufSize, Err *errP)
{
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	UInt32 bytesRead = 0;
	HostTransferSocketInfoType *socketInfoP;
	
	*errP = 0;
	if (gP->curStage != kHostTransferConStageReceiving)	
		{
		gP->curStage = kHostTransferConStageReceiving;	
		PrgUpdateDialog(gP->prgP, *errP, gP->curStage, socketP->description, true);
		}
	
	*errP = PrvProcessEvents(gP, 0);
	
	if (!*errP)
		{
		socketInfoP = (HostTransferSocketInfoType *)socketP->socketRef;
		ErrNonFatalDisplayIf(!socketInfoP, "must call ExgAccept first");
		ErrNonFatalDisplayIf(socketInfoP->op != kHostTransferOpAccept, "must call ExgAccept first");
		ErrNonFatalDisplayIf(!socketInfoP->hostFileP, "host file not open");
		
		// Read the data from the file (allow for partial read).
		bytesRead = HostFRead(bufP, sizeof(char), bufSize, socketInfoP->hostFileP);
		if (bytesRead == 0 && bufSize && !HostFEOF(socketInfoP->hostFileP))
			*errP = exgErrUnknown;
		}
	return bytesRead;
}


/************************************************************
 *
 *  FUNCTION: HostTransferLibControl
 *
 *  DESCRIPTION: Performs a control operation.
 *
 *  PARAMETERS:
 *			->refNum 			- refNum of library
 *			->op				- control operation to perform
 *			<->valueP			- ptr to value for operation
 *			<->valueLenP		- ptr to size of value
 *
 *  CALLED BY: Applications that need to perfrom a control function.
 *
 *  RETURNS:
 *		0						-- no error
 *		exgErrBadParam			-- invalid parameter (unknown operation)
 *		exgErrNotSupported		-- functionality not supported
 *		exgErrNotOpen			-- lib not open
 *
 *  CONTROL FUNCTIONS:
 *		exgLibCtlGetTitle		- get the user-friendly title of the library
 *			<-valueP			- buffer to put title into
 *			->valueLenP			- buffer size - title will be clipped to this size with null terminator
 *		exgLibCtlGetVersion		- get the version of the exg lib API implemented by the library
 *			<-valueP			- 2-byte buffer to put version into
 *		exgLibCtlGetPreview		- find out whether library supports preview
 *			<-valueP			- boolean buffer to put result in
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
Err HostTransferLibControl(UInt16 refNum, UInt16 op, void *valueP, UInt16 *valueLenP)
{
	HostTransferGlobalsType *gP = PrvGetGlobals(refNum);
	Err err = 0;
	
	switch (op)
		{
		case exgLibCtlGetTitle:
			if (valueP && valueLenP)
				{
				MemHandle resourceH;
				Char *resourceP;
#if EMULATION_LEVEL == EMULATION_NONE
				DmOpenRef resourceDBP;
				
				// Open the application/library's database, so we can use it's resources
				resourceDBP = DmOpenDatabaseByTypeCreator(sysFileTApplication, HostTransferCreator, dmModeReadOnly);
				if (! resourceDBP)
					return exgErrBadData;
#endif
				
				// Copy the application name resource
				resourceH = DmGet1Resource(ainRsc, ainID);
				resourceP = MemHandleLock(resourceH);
				StrNCopy(valueP, resourceP, *valueLenP);
				((Char *)valueP)[*valueLenP - 1] = chrNull;	// terminate string if clipped
				MemHandleUnlock(resourceH);
				
#if EMULATION_LEVEL == EMULATION_NONE
				// Close the application/library's database
				DmCloseDatabase(resourceDBP);
#endif
				}
			else
				err = exgErrBadParam;
			break;
		case exgLibCtlGetVersion:
			if (valueP)
				*((UInt16 *)valueP) = exgLibAPIVersion;
			else
				err = exgErrBadParam;
			break;
		case exgLibCtlGetPreview:
			if (valueP)
				*((Boolean *)valueP) = false;
			else
				err = exgErrBadParam;
			break;
		default:
			err = exgErrNotSupported;
		}
	return err;
}


/************************************************************
 *
 *  FUNCTION: PrvTextCallback
 *
 *  DESCRIPTION: Set the appropriate text and icons for the
 *		current stage of the connection. This is called by the progress
 *		manager periodically to update the progress dialogs. We pass a pointer
 *		to this callback when we start the progress manager.
 *
 *  PARAMETERS:
 *
 *  CALLED BY: Progress dialog code.
 *
 *  RETURNS: true if able to generate valid output
 *
 *  CREATED: 1/6/00
 *
 *  BY: Gavin Peacock
 *
 *************************************************************/

#define timeoutTicks 1 * sysTicksPerSecond  // update animation every second.

static Boolean PrvTextCallback(PrgCallbackData *cbP)
{
	Char *message = NULL;
	Boolean addElipsis = true;
	Boolean handled = false;
		
	// Check for animation timeout and update icon if necessary.
	if ((cbP->timedOut) && (cbP->bitmapId != PrgIdleBitmap))
		{
		switch (cbP->bitmapId)
			{
			case Prg1Bitmap:
				cbP->bitmapId = Prg2Bitmap;
				break;
			case Prg2Bitmap:
				cbP->bitmapId = Prg1Bitmap;
				break;
			}
		cbP->textChanged = false;	// do not update text
		cbP->timeout = TimGetTicks() + timeoutTicks;	// if we're way behind, skip frames
		return true;
		}
	
	// If the current error is userCancel, clear it and put dialog into
	// canceling mode (no Cancel button).
	if (cbP->error == exgErrUserCancel)
		{
		cbP->error = 0;
		cbP->canceled = true;
		}
	
     
	// Let the default handlers take care of errors and the canceling status
	if (!cbP->canceled && !cbP->error)
		{
		handled = true;
		message = 0;
		cbP->bitmapId = PrgIdleBitmap;
		cbP->timeout = 0;	// always clear timeout when updating status

		switch ((HostTransferConStageEnum) cbP->stage)
			{
			case kHostTransferConStageInactive:
			case kHostTransferConStageConnected:
				break;

			case kHostTransferConStageSending:
				cbP->bitmapId = Prg1Bitmap;
				message = cbP->message;
				cbP->timeout = timeoutTicks;  // start animation
				break;

			case kHostTransferConStageReceiving:
				cbP->bitmapId = Prg1Bitmap;
				message = cbP->message;
				cbP->timeout = timeoutTicks;  // start animation
				break;

			case kHostTransferConStageInvalid:
			case kHostTransferConStageDisconnecting:
				cbP->bitmapId = PrgIdleBitmap;
				cbP->canceled = true; 		// put dialog in cancel mode (no OK button)
				break;


			default:
				ErrNonFatalDisplayIf(1,"Unknown Stage");
				break;
			} // end of switch
		
		
		// Look up our action string using the stage as a string index
		SysStringByIndex(ProgressStringList, cbP->stage+1, cbP->textP, cbP->textLen);	
			
		// Add extra message text to dialog if it exists...
		if (message)
			{
			StrNCat(cbP->textP, ": ", cbP->textLen);
			StrNCat(cbP->textP, message, cbP->textLen);
			}
			
		// add Elipsis to action oriented strings - since they are not already there for some reason...
		if (addElipsis)
			{
			Char ellipsisString[maxCharBytes + 1];
			ellipsisString[TxtSetNextChar(ellipsisString, 0, chrEllipsis)] = chrNull;
			StrNCat(cbP->textP, ellipsisString, cbP->textLen);
			}
		}
		
		
	// Adjust timeout to beyond current time.
	if (cbP->timeout) cbP->timeout += TimGetTicks();
	
	return handled;
}


/************************************************************
 *
 *  FUNCTION: PrvGetGlobals
 *
 *  DESCRIPTION: Utilty routing to get library globals.
 *
 *  PARAMETERS:
 *				refNum - of the exchange library
 *
 *  RETURNS: pointer to exchange lib Globals - will display error if
 *				unable to find them
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
static HostTransferGlobalsType *PrvGetGlobals(UInt16 refNum)
{
	HostTransferGlobalsType *gP;
	SysLibTblEntryType *libEntryP;
	
	libEntryP = SysLibTblEntry(refNum);
	ErrFatalDisplayIf(!libEntryP, "No HostTransfer lib ref");
	if (!libEntryP) return 0;
	
	gP = libEntryP->globalsP;
	ErrFatalDisplayIf(!gP, "No HostTransfer lib globals" );
	
	return gP;
}


/************************************************************
 *
 *  FUNCTION: PrvProcessEvents
 *
 *  DESCRIPTION: Utility routine handles events during exchange.
 *		We take over the UI from the current app with our progress
 *		dialogs; this handles events for progress.
 *
 *  PARAMETERS:
 *				gp - pointer to library globals
 *				timeout - ticks to wait for events
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
static Err PrvProcessEvents(HostTransferGlobalsType *gP, UInt16 timeout)
{
	EventType event;
	Err err = 0;
	
	if (timeout || EvtEventAvail())
		{
		EvtGetEvent(&event, timeout);
		if (!HostTransferLibHandleEvent(gP->refNum, &event))
			PrgHandleEvent(gP->prgP, &event);  // update progress before waiting...
		}
	else
		PrgHandleEvent(gP->prgP, NULL);  // update progress without event (for animation)
	
	if (gP->prgP)
		{
		err = gP->prgP->error;
		// check for a user cancel and handle it...
		if (PrgUserCancel(gP->prgP))
			err = exgErrUserCancel;
		}
	
	return err;
}


/************************************************************
 *
 *  FUNCTION: PrvStartDialog
 *
 *  DESCRIPTION: Starts the progress dialog if necessary.
 *
 *  PARAMETERS:
 *		gP		 	- library globals
 *
 *	CALLED BY:
 *		Whoever wants to start the dialog
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
static void PrvStartDialog(HostTransferGlobalsType *gP)
{
	if (!gP->prgP)
		{
		UInt16 bufferSize = exgTitleBufferSize;
		Char title[exgTitleBufferSize];
		Err err;
		
		// Get the title of the library
		err = HostTransferLibControl(gP->refNum, exgLibCtlGetTitle, &title, &bufferSize);
		ErrNonFatalDisplayIf(err, "Error getting title");
		
		// Start progress dialogs giving title and progress callback function
		gP->prgP = PrgStartDialog(title, PrvTextCallback,NULL);
		}
}


/************************************************************
 *
 *  FUNCTION: PrvCleanUp
 *
 *  DESCRIPTION: Cleans up after exg transactions. Closes file
 *		and closes status dialog. This should be called whenever
 *		an exg transaction is complete.
 *
 *  PARAMETERS:
 *				gP - pointer library globals
 *				socketP - pointer to the exgSocket
 *
 *  RETURNS: 0 if no error
 *
 *  CREATED: 1/6/00
 *
 *  BY: Danny Epstein
 *
 *************************************************************/
static Err PrvCleanUp(HostTransferGlobalsType *gP, ExgSocketType *socketP)
{
	Err err = 0;
	
	if (socketP && socketP->socketRef)
		{
		HostTransferSocketInfoType *socketInfoP = (HostTransferSocketInfoType *)socketP->socketRef;
		
		switch (socketInfoP->op)
			{
			case kHostTransferOpNone:
				// No operation in progress.
				break;
			
			// It doesn't actually matter whether we're sending or receiving
			// for this library.
			case kHostTransferOpPut:
			case kHostTransferOpAccept:
			case kHostTransferOpGet:
				if (socketInfoP->hostFileP)
					{
					err = HostFClose(socketInfoP->hostFileP);
					if (!err)
						socketInfoP->hostFileP = NULL;
					}
				// This is where we'd delete the file if we were going to
				// delete (partially or completely) read files.
				//FileDelete(0, socketP->name);
				break;
			}
		if (socketInfoP->freeOnDisconnect)
			{
			MemPtrFree(socketInfoP);
			socketP->socketRef = NULL;
			}
		}
	
	// Reset auto off timer so the user has time to react to the transaction.
	EvtResetAutoOffTimer();
	
	// Close progress dialog.
	if (gP->prgP)
		{
		PrgStopDialog(gP->prgP, false);
		gP->curStage = kHostTransferConStageDisconnecting;
		gP->prgP = 0;
		}
	
	return err;
}


/***********************************************************************
 *
 * FUNCTION:    PrvDoSendDialog
 *
 * DESCRIPTION: This displays the dialog that gathers addressing information
 *				from the user. Returns an error or a (possibly edited)
 *				filename.
 *
 * PARAMETERS:  socketP - a pointer to an exgSocketType structure
 *				filenameP - returns the edited filename
 *				errP - returns any error encountered if non-zero
 *
 * RETURNED:    true if ok to proceed, false if not
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			gavin	3/3/00		Initial Revision
 *
 ***********************************************************************/
static Boolean PrvDoSendDialog(ExgSocketType *socketP, Char *filenameP, Err *errP)
{
	MemHandle nameH;
	FormType *formP;
	FieldType *fldP;
	Char **libNames = NULL;
	UInt16 nameLen;
	UInt16 buttonID;
	FormActiveStateType curFrmState;
	Err err = 0;
	Boolean result = false;	// return false on error just to be nice
	Char *nameStr;
	Char *name;
	
#if EMULATION_LEVEL == EMULATION_NONE
	// Open the application/library's database, so we can use it's resources
	DmOpenRef resourceDBP = DmOpenDatabaseByTypeCreator(sysFileTApplication, HostTransferCreator, dmModeReadOnly);
	ErrNonFatalDisplayIf(!resourceDBP, "Error opening resource database");
#endif
	
	// Command Bar should always be cleared before opening a dialog
	//MenuEraseStatus(0);
	
	// Get the form
	formP = FrmInitForm(SendForm);
	
	// Make it active
	FrmSaveActiveState(&curFrmState);				// save active form/window state
	FrmSetActiveForm(formP);      
	
	// Set up field block with current filename
	if (socketP->name && *socketP->name)
		{
		name = StrChr(socketP->name, chrColon);  // strip out the prefix
		if (name)
			name++;
		else
			name = socketP->name;
		nameLen = StrLen(name) + 1;
		}
	else
		nameLen = 0;
	
	nameH = MemHandleNew(nameLen + 1);
	if (!nameH)
		{
		err = exgMemError;
		goto CleanUpAndReturn;
		}
	nameStr = MemHandleLock(nameH);
	if (nameLen)
		StrCopy(nameStr, name);
	else 
		*nameStr = 0;
	MemHandleUnlock(nameH);
	
	fldP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, SendFilenameField));
	FldSetTextHandle(fldP, nameH);
	// Field will take care of freeing it now.
	
	// Draw the form. We could leave this to FrmDoDialog.
	FrmDrawForm(formP);
	
	// Run the dialog
	// doDialog may be called with a form that is active and drawn
	buttonID = FrmDoDialog(formP);
	switch (buttonID)
		{
		case SendSendButton:
			// get our new filename
			nameH = FldGetTextHandle(fldP);
			FldSetTextHandle(fldP, NULL); // remove our handle from the field
			nameStr = MemHandleLock(nameH);
			StrCopy(filenameP, nameStr);
			MemHandleUnlock(nameH);
			MemHandleFree(nameH);
			result = true;
			break;
		case SendCancelButton:
			err = exgErrUserCancel;
			break;
		}
		
CleanUpAndReturn:
	if (libNames)
		MemPtrFree(libNames);
	
	FrmDeleteForm(formP);
	
	FrmRestoreActiveState(&curFrmState);				// restore active form/window state
	
	*errP = err;
	
#if EMULATION_LEVEL == EMULATION_NONE
	err = DmCloseDatabase(resourceDBP);
	ErrNonFatalDisplayIf(err, "Error closing resource database");
#endif
	
	return result;
}
