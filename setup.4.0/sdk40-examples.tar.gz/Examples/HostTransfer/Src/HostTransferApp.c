/******************************************************************************
 *
 * Copyright (c) 2000-2001 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: HostTransferApp.c
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 * Description:
 *		Application portion of the HostTransfer exchange library.
 *
 * History:
 * 1/7/00	dje		Initial version based on Gavin's version
 *
 *****************************************************************************/

#include <PalmOS.h>				// all the system toolbox headers

#include <PalmUtils.h>

#include "ExgLocalLib.h"
#include "HostTransferPrv.h"			// library name, PrvDeleteExistingMacro
#include "HostTransferApp_Res.h"		// application resource defines

#define ChunkSize					20			// memory block allocate size for receive
#define kFeatureNumCurrent		0			// Feature number for last object read
#define kFeatureNumPreview		1			// Feature number for preview preference
#define kExtensions				"exg\ttxt\tfoo"	// extensions we register to receive
#define kUnwrapExtensions		"foo"					// extensions we register to receive directly (auto-unwrap)
#define kCreatorIDs				"todo"				// creator IDs we register to receive (ie. steal)
#define kDefaultFilename		"ExgTest.foo"
#define kDefaultDescription	"Exg Test data"

#define kResponseToGet			"Exg test GET response" // testing response to GET

/***********************************************************************
 * Prototypes for internal functions
 **********************************************************************/
static UInt16 RegisterLibrary(void);
static Err StartApplication(void);
static void StopApplication(void);
static Boolean MainFormHandleEvent(EventType *event);
static void EventLoop(void);

static MenuBarType *CurrentMenu;

extern Err PrvInstallHostTransferDispatcher(UInt16 refNum, SysLibTblEntryType *entryP);

static UInt16 LibRefNum;

static Char EmptyString[1] = "";
static UInt16 ID;
static Char *Types;
static Char **TypePointers;
static UInt32 TypeCount;
static UInt16 TypeIndex;
static UInt32 *CreatorIDs;
static Char *Names;
static Char **NamePointers;
static UInt32 CreatorIDCount;


/***********************************************************************
 *
 * FUNCTION:	RegisterLibrary
 *
 * DESCRIPTION:	This routine registers the HostTransfer exchange library.
 *				- It locks the code segment so that the dispatch table won't move.
 *				- It installs the library.
 *				- It registers the HostTransfer exchange library with the Exchange Manager.
 *				- It registers to be notified when the library/application is deleted.
 *				It also registers the application with the Exchange Manager to receive
 *				certain extensions.
 *				Safe to call repeatedly.
 *
 * PARAMETERS:	None.
 *
 * RETURNED:	reference number of HostTransfer library
 *
 * CALLED BY:	syncNotify, reset, and normal launch codes
 *
 * NOTE:			Poser doesn't currently send syncNotify to installed apps, so
 *					always reset Poser, or run this app, after installing it.
 *
 ***********************************************************************/
static UInt16 RegisterLibrary(void)
{
	MemHandle codeH;
	UInt16 cardNo; 
	LocalID dbID;
	UInt16 refNum;
	Err err;
	
	// Do nothing if the HostTransfer library was already installed.
	if (! SysLibFind(HostTransferName, &refNum))
		return refNum;
	
	// Install the HostTransfer library. This sets up the dispatch table and
	// registers the exchange library with the Exchange Manager.
	SysLibInstall(PrvInstallHostTransferDispatcher, &refNum);
	
#if EMULATION_LEVEL == EMULATION_NONE
	// Lock library/application code segment so it can be used outside this app.
	codeH = DmGet1Resource(sysResTAppCode, 1);
	MemHandleLock(codeH);
#else
	#pragma unused (codeH)
#endif
	
	// Protect the library/application database so that the pre-mortem deletion notification works.
	// Only protected databases trigger the notification.
	SysCurAppDatabase(&cardNo, &dbID);
	DmDatabaseProtect(cardNo, dbID, true);
	
	// Register for pre-mortem deletion notification.
	SysNotifyRegister(cardNo, dbID, sysNotifyDeleteProtectedEvent, NULL, sysNotifyNormalPriority, NULL);
	
	// Register to receive certain extensions.
	err = ExgRegisterDatatype(HostTransferCreator, exgRegExtensionID, kExtensions, "Foo", 0);
	ErrNonFatalDisplayIf(err, "ExgRegisterDatatype failed");
	
	// Register to receive certain extensions with auto-unwrap. (This is a test of the auto-unwrap feature.
	// Attachments with these extensions should be delivered directly rather than being routed through the
	// inbox.)
	err = ExgRegisterDatatype(HostTransferCreator, exgRegExtensionID, kUnwrapExtensions, "Foo", exgUnwrap);
	ErrNonFatalDisplayIf(err, "ExgRegisterDatatype failed");
	
	// Register to receive certain creator IDs. (This is a test of "stealing" incoming todo items from To Do.)
	err = ExgRegisterDatatype(HostTransferCreator, exgRegCreatorID, kCreatorIDs, "Foo", 0);
	ErrNonFatalDisplayIf(err, "ExgRegisterDatatype failed");
	
	// Register to handle mailto URLs. (This lets us test iMessenger's preference dialog.) Note that this
	// overrides our library's registration, so keep it commented out except when testing mailto.
	//ExgRegisterDatatype(HostTransferCreator, exgRegSchemeID, "mailto", "Foo", 0);
	//ErrNonFatalDisplayIf(err, "ExgRegisterDatatype failed");
	
	return refNum;
}


/***********************************************************************
 *
 * FUNCTION:	UnregisterLibrary
 *
 * DESCRIPTION:	This routine unregisters the HostTransfer exchange library.
 *				- It unregisters for pre-mortem deletion notification.
 *				- It un-installs the library.
 *				- It unlocks the code segment.
 *				There's no need to unregister with the Exchange Manager because
 *				the registry gets cleaned up automatically when apps are deleted.
 *
 * PARAMETERS:	None.
 *
 * RETURNED:	none
 *
 * CALLED BY:	pre-mortem deletion notification
 *
 ***********************************************************************/
static void UnregisterLibrary(void)
{
	UInt16 refNum;
	UInt16 cardNo; 
	LocalID dbID;
	MemHandle codeH;
	SysLibTblEntryPtr entryP;
	
	// Do nothing if the HostTransfer library was already removed.
	if (SysLibFind(HostTransferName, &refNum))
		return;
	
	// Unregister for pre-mortem deletion notification.
	SysCurAppDatabase(&cardNo, &dbID);
	SysNotifyUnregister(cardNo, dbID, sysNotifyDeleteProtectedEvent, sysNotifyNormalPriority);
	
	// Unprotect the library/application database so it can be deleted.
	DmDatabaseProtect(cardNo, dbID, false);
	
#if EMULATION_LEVEL == EMULATION_NONE
	// Unlock library/application code segment.
	codeH = DmGet1Resource(sysResTAppCode, 1);
	MemHandleUnlock(codeH);
#else
	#pragma unused (codeH)
#endif
	
	// Free the library's globals.
	entryP = SysLibTblEntry(refNum);
	if (entryP && entryP->globalsP)
		MemPtrFree(entryP->globalsP);
	
	// Remove shortcut-dot-r.
	PrvDeleteExistingMacro(".r");
	
	// Remove the HostTransfer library.
	SysLibRemove(refNum);
}


/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  This routine sets up the initial state of the application.
 *
 * PARAMETERS:   None.
 *
 * RETURNED:     error code
 *
 ***********************************************************************/
static Err StartApplication(void)
{
	LibRefNum = RegisterLibrary();
	
	// Initialize and draw the main memo pad form.
	FrmGotoForm(MainForm);
	
	return 0;
}


/***********************************************************************
 *
 * FUNCTION:     StopApplication
 *
 * DESCRIPTION:  This routine cleans up when the application quits.
 *
 * PARAMETERS:   None.
 *
 * RETURNED:     Nothing.
 *
 ***********************************************************************/
static void StopApplication(void)
{
	FrmCloseAllForms();
}


/***********************************************************************
 *
 * FUNCTION:		ReceiveData
 *
 * DESCRIPTION:		Receives data into the output field using the Exg API.
 *					Also used for preview.
 *
 * PARAMETERS:		exgSocketP - socket from the app code
 *								sysAppLaunchCmdExgReceiveData
 *					string - buffer to put preview into (for preview only)
 *					size - size of buffer (for preview only)
 *
 * RETURNED:		error code or zero for no error.
 *
 ***********************************************************************/
static Err ReceiveData(ExgSocketType *exgSocketP, Char *string, UInt32 size)
{
	Err err;
	MemHandle textH, oldTextH;
	UInt16 textSize, textLen;
	Char * textP;
	Int16 len;
	
	textLen = 0;
	if (exgSocketP->length)
		textSize = exgSocketP->length;
	else
		textSize = ChunkSize;  // allocate in chunks just as an example
							// could use data size from header if available
	textH = MemHandleNew(textSize+1);  // leave room for null terminator
	if (!textH) return -1;  // 
	// This block needs to belong to the system since it could be disposed when apps switch
	MemHandleSetOwner(textH,0);
	// accept will open a progress dialog and wait for your receive commands
	err = ExgAccept(exgSocketP);
	if (!err)
		{
		textP = MemHandleLock(textH);
		do {
			len = ExgReceive(exgSocketP,&textP[textLen],textSize-textLen,&err);
			if (len && !err)
				{
				textLen+=len;
				// resize block when we reach the limit of this one...
				if (textLen >= textSize)
					{
					MemHandleUnlock(textH);
					err = MemHandleResize(textH,textSize+ChunkSize);
					ErrFatalDisplayIf(err,"Unable to allocate memory for data");
					textP = MemHandleLock(textH);
					if (!err) textSize += ChunkSize;
					}
				}
			}
		while (len && !err);   // reading 0 bytes means end of file....
		textP[textLen] = 0;    // always force null terminator for the field package
		if (string)
			StrNCopy(string, textP, size);
		MemHandleUnlock(textH);
		
		ExgDisconnect(exgSocketP, err); // closes transfer dialog
		
		if (string)
			MemHandleFree(textH);
		else
			{
			// Tell ExgMgr to launch this app after receive
			exgSocketP->goToCreator = HostTransferCreator;
			exgSocketP->goToParams.matchCustom = (UInt32)textH;
			
			// We won't get the goto launch code if the HostTransfer lib is reading the data. In
			// this case, this app triggered the HostTransferLibCheck, so this app can update the
			// display. We save the received text in a feature. If several objects are
			// received, we only keep the last one.
			if (! FtrGet(HostTransferCreator, kFeatureNumCurrent, (UInt32 *)&oldTextH))
				MemHandleFree(oldTextH);
			err = FtrSet(HostTransferCreator, kFeatureNumCurrent, (UInt32)textH);
			}
		}
	return err;
}

/***********************************************************************
 *
 * FUNCTION:		GetData
 *
 * DESCRIPTION:		Gets data to the output field using the Exg API
 *
 * CALLED BY:		Main form when Get button is pressed
 *
 * PARAMETERS:		prefix	- the URL scheme, including ":" suffix and
 *							  optional "?" prefix
 *
 * RETURNED:		error code or zero for no error.
 *
 ***********************************************************************/
static Err GetData(const Char *prefix)
{
	static ExgSocketType exgSocket;
	Err err = 0;
	MemHandle textH = NULL;
	UInt16 textSize, textLen;
	Char * textP;
	Int16 len;
	
	textLen = 0;
	
	// important to init structure to zeros...
	MemSet(&exgSocket, sizeof(exgSocket), 0);
	// Construct URL to put in name field.
	exgSocket.name = MemPtrNew(StrLen(prefix) + StrLen(kDefaultFilename) + 1);
	StrCopy(exgSocket.name, prefix);
	StrCat(exgSocket.name, kDefaultFilename);
	err = ExgGet(&exgSocket);
	if (!err)
		{
		if (exgSocket.length)
			textSize = exgSocket.length;
		else
			textSize = ChunkSize;  // allocate in chunks just as an example
								// could use data size from header if available
		textH = MemHandleNew(textSize+1);  // leave room for null terminator
		if (!textH) return -1;  // 

		textP = MemHandleLock(textH);
		do {
			len = ExgReceive(&exgSocket,&textP[textLen],textSize-textLen,&err);
			if (len && !err)
				{
				textLen+=len;
				// resize block when we reach the limit of this one...
				if (textLen >= textSize)
					{
					MemHandleUnlock(textH);
					err = MemHandleResize(textH,textSize+ChunkSize);
					ErrFatalDisplayIf(err,"Unable to allocate memory for data");
					textP = MemHandleLock(textH);
					if (!err) textSize += ChunkSize;
					}
				}
			}
		while (len && !err);   // reading 0 bytes means end of file....
		textP[textLen] = 0;    // always force null terminator for the field package
		MemHandleUnlock(textH);
		
		ExgDisconnect(&exgSocket, err); // closes transfer dialog
		
		}
		
	if (textH && !err)
		{			
		FormType *formP;
		FieldType *fieldP;
		formP = FrmGetFormPtr(MainForm);
		fieldP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, MainInDataField));
		textH = (MemHandle)textH;
		
		// Update the field text
		if (fieldP && textH)
			{
			FldFreeMemory(fieldP);
			FldSetTextHandle(fieldP, textH);
			FldDrawField(fieldP);
			textH = NULL;  // memory belongs tothe field now.
			}
		}
	if (textH) MemHandleFree(textH);
	return err;
}


/***********************************************************************
 *
 * FUNCTION:		SendData
 *
 * DESCRIPTION:		Sends data in the input field using the Exg API
 *
 * CALLED BY:		Main form when Beam or Send button is pressed
 *
 * PARAMETERS:		prefix	- the URL scheme, including ":" suffix and
 *							  optional "?" prefix
 *
 * RETURNED:		error code or zero for no error.
 *
 ***********************************************************************/
#define testRepeater 1  // # of times to duplicate sender data...
#define testDelay 1  // delay after each send, to see dialogs...

// turn on to translate LF to CR/LF (and send really slowly)
#define WANTCRLFPAIRS 0	

static Err SendData(const Char *prefix)
{
	FormType *frm;
	FieldType *fld;
	Char * text;
	UInt16 sLen;
	char null = 0;
	static ExgSocketType exgSocket;
	Err err = 0;
	
	frm = FrmGetFormPtr(MainForm);
	fld = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, MainOutDataField));
	// Get a pointer to the field's text.
	text = FldGetTextPtr(fld);
	
	// Is there data in the field?
	if (text != NULL && *text != 0)
		{
		sLen = StrLen(text);
		// important to init structure to zeros...
		MemSet(&exgSocket, sizeof(exgSocket), 0);
		
		// Construct URL to put in name field.
		exgSocket.name = MemPtrNew(StrLen(prefix) + StrLen(kDefaultFilename) + 1);
		StrCopy(exgSocket.name, prefix);
		StrCat(exgSocket.name, kDefaultFilename);
		
		exgSocket.description = MemPtrNew(StrLen(kDefaultDescription) + 1);
		StrCopy(exgSocket.description, kDefaultDescription);
		exgSocket.length = sLen * testRepeater + 1;
		exgSocket.target = HostTransferCreator;
		err = ExgPut(&exgSocket);   // put data to destination
		if (!err)
			{
			int i;
			for (i=0;i<testRepeater && !err;i++) 
				{
#if WANTCRLFPAIRS
				int j;
				for (j=0; j<sLen && !err; j++)
					{
					if (text[j] == linefeedChr)
						ExgSend(&exgSocket,"\015",1,&err);
					ExgSend(&exgSocket,&text[j],1,&err);
					}
#else
				ExgSend(&exgSocket, text, sLen, &err);
#endif
				SysTaskDelay(testDelay);
				}
			//ExgSend(&exgSocket, &null, 1, &err); // write null at end...
			ExgDisconnect(&exgSocket, err);
			}
		
		// Free name and description allocated above. Name may have been edited by user.
		if (exgSocket.name)
			MemPtrFree(exgSocket.name);
		if (exgSocket.description)
			MemPtrFree(exgSocket.description);
		}
	
	return err;
}


/***********************************************************************
 *
 * FUNCTION:	GoToItem
 *
 * DESCRIPTION:	Displays the given text
 *
 * PARAMETERS:	textH - text to display
 *
 * RETURNED:	nothing
 *
 ***********************************************************************/
static void GoToItem(MemHandle textH)
{
	EventType event;
	
	if (textH)
		{
		// Enqueue a goto event rather than actually updating the display immediately
		// because the form might not be open yet.
		MemSet(&event, sizeof(EventType), 0);
		event.eType = frmGotoEvent;
		event.data.frmGoto.formID = MainForm;
		event.data.frmGoto.matchCustom = (UInt32)textH;
		EvtAddEventToQueue(&event);
		}
}


/***********************************************************************
 *
 * FUNCTION:    GetShortStringPreview
 *
 * DESCRIPTION: Get a short string preview.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void GetShortStringPreview(void)
{
	ExgLocalSocketInfoType socketInfo;
	ExgSocketType socket;
	ExgPreviewInfoType previewInfo;
	Char previewString[80];
	Char data[] = "Test short string preview\nSecond line";
	UInt32 bytesSent;
	Err err;
	
	MemSet(&socketInfo, sizeof(socketInfo), 0);
	socketInfo.previewInfoP = &previewInfo;
	socketInfo.noAsk = true;
	
	MemSet(&socket, sizeof(socket), 0);
	socket.name = (Char *)"_local:test.foo";
	socket.socketRef = (UInt32)&socketInfo;
	socket.noStatus = true;
	
	MemSet(&previewInfo, sizeof(previewInfo), 0);
	previewInfo.op = exgPreviewShortString;
	previewInfo.string = previewString;
	previewInfo.size = sizeof(previewString);
	previewInfo.socketP = &socket;
	
	err = ExgPut(&socket);
	ErrFatalDisplayIf(err, "ExgPut failed");
	
	bytesSent = ExgSend(&socket, &data, sizeof(data), &err);
	ErrFatalDisplayIf(err, "ExgSend failed");
	ErrFatalDisplayIf(bytesSent != sizeof(data), "Not all data sent");
	
	err = ExgDisconnect(&socket, err);
	ErrFatalDisplayIf(err, "ExgDisconnect failed");
	
	FrmCustomAlert(PreviewAlert, previewInfo.string, NULL, NULL);
}


/***********************************************************************
 *
 * FUNCTION:    GetDialogPreview
 *
 * DESCRIPTION: Get a dialog preview.
 *
 * PARAMETERS:  none
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void GetDialogPreview(void)
{
	ExgLocalSocketInfoType socketInfo;
	ExgSocketType socket;
	ExgPreviewInfoType previewInfo;
	Char data[] = "Test dialog preview\nSecond line";
	UInt32 bytesSent;
	Err err;
	
	MemSet(&socketInfo, sizeof(socketInfo), 0);
	socketInfo.previewInfoP = &previewInfo;
	socketInfo.noAsk = true;
	
	MemSet(&socket, sizeof(socket), 0);
	socket.name = (Char *)"_local:test.foo";
	socket.socketRef = (UInt32)&socketInfo;
	socket.noStatus = true;
	
	MemSet(&previewInfo, sizeof(previewInfo), 0);
	previewInfo.op = exgPreviewDialog;
	previewInfo.socketP = &socket;
	
	err = ExgPut(&socket);
	ErrFatalDisplayIf(err, "ExgPut failed");
	
	bytesSent = ExgSend(&socket, &data, sizeof(data), &err);
	ErrFatalDisplayIf(err, "ExgSend failed");
	ErrFatalDisplayIf(bytesSent != sizeof(data), "Not all data sent");
	
	err = ExgDisconnect(&socket, err);
	ErrFatalDisplayIf(err, "ExgDisconnect failed");
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void MainFormDoCommand(UInt16 command)
{
	switch (command)
		{
		case PreviewDialog:
			FtrSet(HostTransferCreator, kFeatureNumPreview, exgPreviewDialog);
			break;
		case PreviewGraphical:
			FtrSet(HostTransferCreator, kFeatureNumPreview, exgPreviewDraw);
			break;
		case PreviewLongString:
			FtrSet(HostTransferCreator, kFeatureNumPreview, exgPreviewLongString);
			break;
		case PreviewShortString:
			FtrSet(HostTransferCreator, kFeatureNumPreview, exgPreviewShortString);
			break;
		case PreviewDefault:
			FtrUnregister(HostTransferCreator, kFeatureNumPreview);
			break;
		case OptionsSend:
			SendData(exgSendBeamPrefix);
			break;
		case OptionsPreferences:
			FrmPopupForm(PreferencesForm);
			break;
		case OptionsGetShortStringPreview:
			GetShortStringPreview();
			break;
		case OptionsGetDialogPreview:
			GetDialogPreview();
			break;
		}
}


/***********************************************************************
 *
 * FUNCTION:	MainFormHandleEvent
 *
 * DESCRIPTION:	Handles processing of events for the �main� form.
 *
 * PARAMETERS:	event	- the most recent event.
 *
 * RETURNED:	True if the event is handled, false otherwise.
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventType *event)
{
	MemHandle textH;
	Boolean handled = false;
	FormType *formP;
	FieldType *fieldP;
	UInt32 numLibs;
	
	switch (event->eType)
	{
		case ctlSelectEvent:
		
			switch (event->data.ctlEnter.controlID)
				{
				case MainBeamButton:
					SendData(exgBeamPrefix);
					break;
				case MainSendButton:
					SendData(exgSendPrefix);
					break;
				case MainHostButton:
					SendData(kHostTransferPrefix);
					break;
				case MainGetButton:
					GetData(exgSendBeamPrefix); 
					break;
				case MainCheckButton:
					ExgLibRequest(LibRefNum, NULL);
					
					// Go to the last object read
					if (! FtrGet(HostTransferCreator, kFeatureNumCurrent, (UInt32 *)&textH))
						{
						GoToItem(textH);
						FtrUnregister(HostTransferCreator, kFeatureNumCurrent);
						}
					
					break;
				}
			break;
		
		case frmOpenEvent:
			FrmDrawForm(FrmGetActiveForm());
			break;
		
		case menuOpenEvent:
			if (ExgGetRegisteredApplications(NULL, &numLibs, NULL, NULL, exgRegSchemeID, exgBeamScheme "\t" exgSendScheme) || ! numLibs)
				MenuHideItem(OptionsSend);
			else
				MenuShowItem(OptionsSend);
			// don't set handled = true
			break;
		
		case menuEvent:
			MainFormDoCommand(event->data.menu.itemID);
			break;
		
		case frmGotoEvent:
			formP = FrmGetFormPtr(MainForm);
			fieldP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, MainInDataField));
			textH = (MemHandle)event->data.frmGoto.matchCustom;
			
			// Update the field text
			if (fieldP && textH)
				{
				FldFreeMemory(fieldP);
				FldSetTextHandle(fieldP, textH);
				FldDrawField(fieldP);
				}
				handled = true;
			break;
		}
	return(handled);
}


/***********************************************************************
 *
 * FUNCTION:    PreferencesHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the Preferences
 *              dialog.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			dje	8/4/00	Initial Revision
 *
 * DOLATER dje - Free globals when overwritten and when form exits.
 *
 ***********************************************************************/
static Boolean PreferencesHandleEvent(EventType *eventP)
{
	Boolean handled = false;
	FormPtr formP;
	Err err;
	ControlType *triggerP;
	ListType *listP;
	UInt16 i;
	MemHandle typePointersH;
	UInt32 creatorID;
	
	switch (eventP->eType)
		{
		case frmOpenEvent:
			formP = FrmGetActiveForm();
			FrmDrawForm(formP);
			handled = true;
			break;
	
		case popSelectEvent:
			switch (eventP->data.popSelect.controlID)
				{
				case PreferencesIDPopTrigger:
					formP = FrmGetActiveForm();
					switch (eventP->data.popSelect.selection)
						{
						case 0: ID = exgRegExtensionID; break;
						case 1: ID = exgRegTypeID; break;
						case 2: ID = exgRegSchemeID; break;
						case 3: ID = exgRegCreatorID; break;
						}
					err = ExgGetRegisteredTypes(&Types, &TypeCount, ID);
					ErrFatalDisplayIf(err, "ExgGetRegisteredTypes failed");
					if (TypeCount == 0)
						{
						Types = EmptyString;
						TypePointers = NULL;
						}
					else
						{
						typePointersH = SysFormPointerArrayToStrings(Types, TypeCount);
						TypePointers = MemHandleLock(typePointersH);
						}
					listP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, PreferencesTypeList));
					LstSetListChoices(listP, TypePointers, TypeCount);
					LstSetHeight(listP, min(TypeCount, 5));
					triggerP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, PreferencesTypePopTrigger));
					CtlSetLabel(triggerP, EmptyString);
					triggerP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, PreferencesDefaultPopTrigger));
					CtlSetLabel(triggerP, EmptyString);
					listP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, PreferencesDefaultList));
					LstSetListChoices(listP, NULL, 0);
					break;
				
				case PreferencesTypePopTrigger:
					formP = FrmGetActiveForm();
					TypeIndex = eventP->data.popSelect.selection;
					err = ExgGetRegisteredApplications(&CreatorIDs, &CreatorIDCount, &Names, NULL, ID, TypePointers[TypeIndex]);
					ErrFatalDisplayIf(err, "ExgGetRegisteredApplications failed");
					if (CreatorIDCount)
						{
						MemHandle namePointersH = SysFormPointerArrayToStrings(Names, CreatorIDCount);

						if (ID == exgRegCreatorID)
							{
							CreatorIDCount++;	// for the app itself
							MemHandleResize(namePointersH, CreatorIDCount * sizeof(Char *));
							NamePointers = MemHandleLock(namePointersH);
							NamePointers[CreatorIDCount - 1] = TypePointers[TypeIndex];	// use the creator ID
							}
						else
							NamePointers = MemHandleLock(namePointersH);
						}
					else
						NamePointers = NULL;
					listP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, PreferencesDefaultList));
					LstSetListChoices(listP, NamePointers, CreatorIDCount);
					LstSetHeight(listP, min(CreatorIDCount, 5));
					err = ExgGetDefaultApplication(&creatorID, ID, TypePointers[eventP->data.popSelect.selection]);
					ErrFatalDisplayIf(err, "ExgGetDefaultApplication failed");
					triggerP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, PreferencesDefaultPopTrigger));
					for (i = 0; i < CreatorIDCount; i++)
						if (MemCmp(&creatorID,
							((ID == exgRegCreatorID && i == CreatorIDCount - 1)
								? (void *)TypePointers[TypeIndex]
								: (void *)&CreatorIDs[i]), 4) == 0)
							{
							CtlSetLabel(triggerP, NamePointers[i]);
							LstSetSelection(listP, i);
							}
					break;
				
				case PreferencesDefaultPopTrigger:
					MemMove(&creatorID,
						((ID == exgRegCreatorID && eventP->data.popSelect.selection == CreatorIDCount - 1)
							? (void *)TypePointers[TypeIndex]
							: (void *)&CreatorIDs[eventP->data.popSelect.selection]), 4);
					err = ExgSetDefaultApplication(creatorID, ID, TypePointers[TypeIndex]);
					ErrFatalDisplayIf(err, "ExgSetDefaultApplication failed");
					break;
				}
			break;
		
		case ctlSelectEvent:
			switch (eventP->data.ctlSelect.controlID)
				{
				case PreferencesDoneButton:
					FrmReturnToForm(0);
					handled = true;
					break;
				}
			break;
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    ApplicationHandleEvent
 *
 * DESCRIPTION: This routine loads a form resource and sets the event handler for the form.
 *
 * PARAMETERS:  event - a pointer to an EventType structure
 *
 * RETURNED:    True if the event has been handled and should not be
 *				passed to a higher level handler.
 *
 ***********************************************************************/
static Boolean ApplicationHandleEvent(EventType *event)
{
	FormType *formP;
	UInt16 formId;
	Boolean handled = false;

	if (event->eType == frmLoadEvent)
		{
		// Load the form resource specified in the event then activate the form.
		formId = event->data.frmLoad.formID;
		formP = FrmInitForm(formId);
		FrmSetActiveForm(formP);

		// Set the event handler for the form.  The handler of the currently 
		// active form is called by FrmDispatchEvent each time it receives an event.
		switch (formId)
			{
			case MainForm:
				FrmSetEventHandler(formP, MainFormHandleEvent);
				break;
			case PreferencesForm:
				FrmSetEventHandler(formP, PreferencesHandleEvent);
				break;
			}
		handled = true;
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:	EventLoop
 *
 * DESCRIPTION:	A simple loop that obtains events from the Event
 *				Manager and passes them on to various applications and
 *				system event handlers before passing them on to
 *				FrmHandleEvent for default processing.
 *
 * PARAMETERS:	None.
 *
 * RETURNED:	Nothing.
 *
 ***********************************************************************/
static void EventLoop(void)
{
	EventType event;
	UInt16 error;
	
	do
		{
		// Get the next available event.
		EvtGetEvent(&event, evtWaitForever);
		
		// Give the system a chance to handle the event.
		if (! SysHandleEvent (&event))

			// Give the menu a chance to handle the event
			if (! MenuHandleEvent(0, &event, &error))

				// Give the application a chance to handle the event.
				if (! ApplicationHandleEvent(&event))

					// Let the form object provide default handling of the event.
					FrmDispatchEvent(&event);
		} 
	while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: Check that the ROM version meets your
 *              minimum requirement.  Warn if the app was switched to.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags indicating how the application was
 *								  launched.  A warning is displayed only if
 *								  these flags indicate that the app is 
 *								  launched normally.
 *
 * RETURNED:    zero if rom is compatible else an error code
 *                             
 ***********************************************************************/
static Err RomVersionCompatible (UInt32 requiredVersion, UInt8 launchFlags)
{
	UInt32 romVersion;
	
	// See if we're on in minimum required version of the ROM or later.
	// The system records the version number in a feature.  A feature is a
	// piece of information which can be looked up by a creator and feature
	// number.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		// If the user launched the app from the launcher, explain
		// why the app shouldn't run.  If the app was contacted for something
		// else, like it was asked to find a string by the system find, then
		// don't bother the user with a warning dialog.  These flags tell how
		// the app was launched to decided if a warning should be displayed.
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.  The sysFileCDefaultApp is considered "safe".
			if (romVersion < 0x02000000)
				{
				Err err = 0;
				
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
				}
			}
		
		return (sysErrRomIncompatible);
		}

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:	PilotMain
 *
 * DESCRIPTION:	This function is the equivalent of a main() function
 *				in standard �C�.  It is called by the Emulator to begin
 *				execution of this application.
 *
 * PARAMETERS:	cmd - command specifying how to launch the application.
 *				cmdPBP - parameter block for the command.
 *						launchFlags - flags used to configure the launch.			
 *
 * RETURNED:	Any applicable error code.
 *
 ***********************************************************************/
UInt32 PilotMain(UInt16 cmd, void *cmdPBP, UInt16 launchFlags)
{
	UInt32 err = 0;
	
	// This app makes use of PalmOS 4.0 features.  It will crash if
	// run on an earlier version of PalmOS.  Detect and warn if this
	// happens, then exit.  We use the 4.0 exg lib API.
	err = RomVersionCompatible(kVersion4_0, launchFlags);
	if (err)
		return err;
	
	// Check for a normal launch.
	if (cmd == sysAppLaunchCmdNormalLaunch)
		{
		// Set up initial form.
		err = StartApplication();
		
		if (err)
			return err;
		
		// Start up the event loop.
		EventLoop();
		
		StopApplication();
		}
	else if (cmd == sysAppLaunchCmdSyncNotify)
		{
		RegisterLibrary();
		}
	else if (cmd == sysAppLaunchCmdSystemReset)
		{
		RegisterLibrary();	// see note on RegisterLibrary
		}
	//else if (cmd == sysAppLaunchCmdExgAskUser)
	//	{
	//	ExgAskParamType *paramP = (ExgAskParamType *)cmdPBP;
	//	}
	else if (cmd == sysAppLaunchCmdExgReceiveData)
		{
		// This call may be made from another application, so your
		// app must not assume that it's globals are initialized.
		Boolean appIsActive = launchFlags & sysAppLaunchFlagSubCall;
		if (!appIsActive)
			{
			// if this test passses,
			// your app is NOT running,so you cannot use app globals
			}
		err = ReceiveData((ExgSocketType *)cmdPBP, NULL, 0);
		}
	else if (cmd == sysAppLaunchCmdGoTo)
		{
		// This call may be made from another application, so your
		// app must not assume that it's globals are initialized.
		Boolean launched;
		
		launched = launchFlags & sysAppLaunchFlagNewGlobals;
		
		if (launched) 
			{
			err = StartApplication();
			if (err) 
				return (err);
			}

		GoToItem((MemHandle)((GoToParamsType *)cmdPBP)->matchCustom);
		FtrUnregister(HostTransferCreator, kFeatureNumCurrent);

		if (launched) 
			{
			EventLoop();
			StopApplication();   
			}      
		}
	else if (cmd == sysAppLaunchCmdExgPreview)
		{
		// This call may be made from another application, so your
		// app must not assume that it's globals are initialized.
		ExgPreviewInfoType *infoP = cmdPBP;
		RectangleType oldClip, rect;
		Char description[40], *firstReturn;
		UInt32 previewType;
		
		switch (infoP->op)
			{
			case exgPreviewQuery:
				if (FtrGet(HostTransferCreator, kFeatureNumPreview, &previewType))
					infoP->types = exgPreviewShortString | exgPreviewLongString | exgPreviewDraw | exgPreviewDialog;
				else
					infoP->types = (UInt16)previewType;
				break;
			
			case exgPreviewShortString:
				// Use the first line of the text.
				infoP->error = ReceiveData(infoP->socketP, infoP->string, infoP->size);
				if (! infoP->error && infoP->string)
					{
					firstReturn = StrChr(infoP->string, chrLineFeed);
					if (firstReturn)
						*firstReturn = chrNull;
					}
				break;
			
			case exgPreviewLongString:
				// Use the entire text.
				infoP->error = ReceiveData(infoP->socketP, infoP->string, infoP->size);
				break;
			
			case exgPreviewDraw:
				// Draw the first line of the text in the large font inside a gray rectangle.
				infoP->error = ReceiveData(infoP->socketP, description, sizeof(description));
				if (! infoP->error)
					{
					firstReturn = StrChr(description, chrLineFeed);
					if (firstReturn)
						*firstReturn = chrNull;
					
					WinPushDrawState();
					WinGetClip(&oldClip);
					RctCopyRectangle(&infoP->bounds, &rect);
					WinClipRectangle(&rect);
					WinSetClip(&rect);
					FntSetFont(largeBoldFont);
					RctCopyRectangle(&infoP->bounds, &rect);
					RctInsetRectangle(&rect, 1);
					WinDrawGrayRectangleFrame(rectangleFrame, &rect);
					WinDrawTruncChars(description, StrLen(description),
						rect.topLeft.x, rect.topLeft.y, rect.extent.x);
					WinSetClip(&oldClip);
					WinPopDrawState();
					}
				break;
			
			case exgPreviewDialog:
				infoP->error = ReceiveData(infoP->socketP, description, sizeof(description));
				if (! infoP->error)
					{
					firstReturn = StrChr(description, chrLineFeed);
					if (firstReturn)
						*firstReturn = chrNull;
					FrmCustomAlert(PreviewAlert, description, NULL, NULL);
					}
				break;
			}
		}
	else if (cmd == sysAppLaunchCmdExgGetData)
		{	Err err;
			ExgSocketType *exgSocketP = (ExgSocketType *)cmdPBP;
			err = ExgSend(exgSocketP,kResponseToGet,StrLen(kResponseToGet)+1,&err);
			ExgDisconnect(exgSocketP,err);
	
		}
	else if (cmd == sysAppLaunchCmdNotify)
		{
		switch (((SysNotifyParamType*) cmdPBP)->notifyType)
			{
			case sysNotifyDeleteProtectedEvent:
				UnregisterLibrary();	// unregister before we get deleted
				break;
			}
		}
	
	return err;
}
