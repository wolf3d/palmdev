/******************************************************************************
 *
 * Copyright (c) 2000 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: DateRelPrefix.h
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 *****************************************************************************/

//#include <BuildDefines.h>
//#include <MemCheckBuildDefines.h>

#define ERROR_CHECK_LEVEL	ERROR_CHECK_NONE
#define MEM_CHECK_LEVEL		MEM_CHECK_NONE
#define TRACE_OUTPUT		TRACE_OUTPUT_OFF

//#include <BuildDefaults.h>
//#include <MemCheckBuildDefault.h>
