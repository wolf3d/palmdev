/******************************************************************************
 *
 * Copyright (c) 1996-2000 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: FormatsPanel.c
 *
 * Release: Palm OS SDK 4.0 (63220)
 *
 * Description:
 *	  This is the Formats Panel's main module.  This module
 *   starts the panel, dispatches events, and stops
 *   the panel. 
 *
 *   This panel is an SDK example because it shows two things well.
 *   1. It shows how to make a panel properly so it interacts well with
 *   other panels in the preference area and 
 *	  2. It shows how to use the localized information for times, dates, 
 *	  and numbers well.
 *
 * History:
 *		6/3/96	rf		Created by Roger Flores
 *		4/18/00	jmp	Added support for dfMDYWithDashes format.
 *		7/30/00  vivek Added support for sysAppLaunchCmdLocaleChanging.
 *
 *****************************************************************************/

#include <PalmOS.h>
#include <PalmUtils.h>
#include "FormatsPanel.h"

/***********************************************************************
 *	Internal Constants
 ***********************************************************************/

#define defaultTimeButton	timeHourButton

//	Separator line on Formats form
#define formatsSepLineYPos		34

//	Measurements needed for displaying time & dates on Formats form.
// By using compiled in coordinates the app must be recompiled if someone
// tries to move around the ui.  A different choice would be to use labels. 
// This way trades flexibility for size and speed.
#define lineSpacing				12
#define timeDisplayXPos			89
#define timeDisplayYPos			52
#define dateDisplayXPos			timeDisplayXPos
#define dateDisplayYPos			(timeDisplayYPos + 2 * lineSpacing)

// How far buttons should be from each other when they are moved because
// the Done button needs to appear.
#define ButtonSeparationXDistance	6

/***********************************************************************
 *	Internal typedefs
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			CS		07/16/99	Added daylightSavings & minutesWestOfGMT
 *								to FormatsPreferencesType, even though we don't
 *								allow user to modify them directly, since they
 *								should track country changes as well.
 *			CS		05/02/00	Changed country to localeIndex, and weekStartDay
 *								from UInt8 to UInt16.
 *			CS		05/02/00	Defined LocaleCountryNamesType.
 *			CS		07/28/00	Tossed daylightSavings & minutesWestOfGMT,
 *								since these guys are now controlled via
 *								a separate interface and no longer track
 *								country switches.
 *
 ***********************************************************************/

typedef struct 
	{
	// system preferences changed by this panel
	UInt16 localeIndex;					// Index of locale (chosen via country name)
	UInt16 weekStartDay;					// Sunday or Monday
	NumberFormatType numberFormat;	// Format to display numbers in
	TimeFormatType timeFormat;			// Format to display time in
	DateFormatType dateFormat;			// Format to display date in
	DateFormatType longDateFormat;	// Format to display date in
	MeasurementSystemType measurementSystem;	// Format for measurements (English, metric)
	} FormatsPreferencesType;
	
typedef Char (*LocaleCountryNamesType)[kMaxCountryNameLen+1];
	
/***********************************************************************
 *	Local function prototypes
 ***********************************************************************/

static void FormatsFormDrawForm (void);
static void FormatsFormForceDrawForm (void);
static void SetPreferencesByLocale(FormatsPreferencesType* formatsPreferencesP, 
		UInt16 localeIndex);

/***********************************************************************
 *	Global variables
 ***********************************************************************/
static Boolean CalledFromAppMode;
		// True means hide the panel pick list and display a Done button to
		// return to the calling app.

static UInt16 panelCount;
static MemHandle panelIDsH;			// MemHandle to block containing pick list items
static SysDBListItemType *panelIDsP = 0;	// ptr to block containing pick list items

static FormatsPreferencesType FormatsPreferences;
char FormatsFormTimeString[timeStringLength];
char FormatsFormDateString[dateStringLength];
char FormatsFormLongDateString[longDateStrLength];

// A sorted list of locale indexes for building the Preset To: menu.
static UInt16* LocaleOrderP = NULL;

// An array of country names, indexed by locale index.
static LocaleCountryNamesType LocaleCountryNamesP = NULL;

TimeFormatType TimeFormatMappings[timeFormatsSelectable] =
	{
	tfColonAMPM, tfColon24h, tfDotAMPM, tfDot24h, tfComma24h
	};

//	Map ui list positions to Int16 date formats
DateFormatType DateFormatMappings[dateFormatsSelectable] =
	{	
	//	All of the Int16 date formats:
	dfMDYWithSlashes, dfDMYWithSlashes, dfDMYWithDots,
	dfDMYWithDashes, dfYMDWithSlashes, dfYMDWithDots,
	dfYMDWithDashes, dfMDYWithDashes
	};

//	Map ui list positions to long date formats
DateFormatType LongDateFormatMappings[dateFormatsSelectable] =
	{
	dfMDYLongWithComma, dfDMYLong, dfDMYLongWithDot,
	dfDMYLong, dfYMDLongWithSpace, dfYMDLongWithDot,
	dfYMDLongWithSpace, dfMDYLongWithComma
	};


/***********************************************************************
 *
 * FUNCTION:		CompareLocaleCountries
 *
 * DESCRIPTION:	Compare two locale indexes, based on their country
 *						names so that we can build a sorted list.
 *
 * PARAMETERS:		nothing
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/5/96	Initial Revision
 *			CS		05/02/00	Rewrote to base on locale indexes.
 *
 ***********************************************************************/
static Int16 CompareLocaleCountries(void* localeIndexA, void* localeIndexB,
	Int32 localeCountryNamesP)
{
	return(StrCompare(((LocaleCountryNamesType)localeCountryNamesP)
								[*(UInt16*)localeIndexA],
							((LocaleCountryNamesType)localeCountryNamesP)
								[*(UInt16*)localeIndexB]));
}


/***********************************************************************
 *
 * FUNCTION:     RegisterLocaleChangingNotification

 *
 * DESCRIPTION:  Register for NotifyMgr notifications for locale chagning.
 *						 
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vivek	8/01/00	Initial Revision
 *
 ***********************************************************************/
static void RegisterLocaleChangingNotification(void)
{
	UInt16 cardNo;
	LocalID dbID;
	Err err;
				
	// Register for volume mounted/unmounted events:
	err = SysCurAppDatabase(&cardNo, &dbID);
	ErrNonFatalDisplayIf(err != errNone, "can't get app db info");
	if(err == errNone)
	{
		err = SysNotifyRegister(cardNo, dbID, sysNotifyLocaleChangedEvent, 
						NULL, sysNotifyNormalPriority, NULL);

#if EMULATION_LEVEL == EMULATION_NONE
		ErrNonFatalDisplayIf((err != errNone) && (err != sysNotifyErrDuplicateEntry), "can't register");
#endif
		
	}
	
	return;
}		

/***********************************************************************
 *
 * FUNCTION:     HandleLocaleChangedNotification

 *
 * DESCRIPTION:  Handle the locale changed notification
 *						 
 *
 * PARAMETERS:   formatsPrefsP; a pointer to the formats prefs
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vivek	8/05/00	Initial Revision
 *
 ***********************************************************************/
static void HandleLocaleChangedNotification(FormatsPreferencesType* formatsPrefsP)
{
	LmLocaleType prefsLocale;
	Int16			 timeZone;
	Err 			 theErr = errNone;
	
	SetPreferencesByLocale(formatsPrefsP, formatsPrefsP->localeIndex);

	theErr = LmGetLocaleSetting(	formatsPrefsP->localeIndex,
											lmChoiceTimeZone, 
											&timeZone,
											sizeof(timeZone));
	ErrNonFatalDisplayIf(theErr, "Can\'t get new locale\'s default time zone");

	theErr = LmGetLocaleSetting(	formatsPrefsP->localeIndex,
											lmChoiceLocale,
											&prefsLocale,
											sizeof(prefsLocale));
	ErrNonFatalDisplayIf(theErr, "Can\'t get locale");

	PrefSetPreference(prefTimeZone, timeZone);
	PrefSetPreference(prefTimeZoneCountry, prefsLocale.country);
}	

/***********************************************************************
 *
 * FUNCTION:     StartApplication
 *
 * DESCRIPTION:  Get the current system preferences which we may change.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/4/96	Initial Revision
 *			CS		07/16/99	Get prefDaylightSavings & prefMinutesWestOfGMT
 *								even though we don't allow user to modify them
 *								directly, since they should track country
 *								changes as well.
 *			CS		05/02/00	Rewrote to use LocaleOrderP list of sorted locale
 *								indexes and new CompareLocaleCountries compare
 *								function.
 *			CS		05/16/00	LmCountryType/LmLanguageType are now back to
 *								CountryType/LanguageType.
 *			CS		07/28/00	Tossed daylightSavings & minutesWestOfGMT,
 *								since these guys are now controlled via
 *								a separate interface and no longer track
 *								country switches.
 *			CS		08/01/00	Search locales for a complete match with new
 *								locale preference.
 *
 ***********************************************************************/
static UInt16 StartApplication (void)
{
	UInt16 numLocales = LmGetNumLocales();
	MemHandle tMemHandle = NULL;
	UInt16 localeIndex;
	UInt32 prefsLocale;
	Err theErr = errNone;

#if EMULATION_LEVEL != EMULATION_NONE
	RegisterLocaleChangingNotification();
#endif
	
	// Get the system preferences that this panel allows changing
	FormatsPreferences.timeFormat = (TimeFormatType) PrefGetPreference(prefTimeFormat);
	FormatsPreferences.dateFormat = (DateFormatType) PrefGetPreference(prefDateFormat);
	FormatsPreferences.longDateFormat = (DateFormatType) PrefGetPreference(prefLongDateFormat);
	FormatsPreferences.weekStartDay = PrefGetPreference(prefWeekStartDay);
	FormatsPreferences.numberFormat = (NumberFormatType) PrefGetPreference(prefNumberFormat);
	FormatsPreferences.measurementSystem = (MeasurementSystemType)PrefGetPreference(prefMeasurementSystem);
	
	// Find the index of the first known locale whose country matches the country
	// from preferences (or use 0 if none match)
	prefsLocale = PrefGetPreference(prefLocale);
	FormatsPreferences.localeIndex = 0;
	for (localeIndex = 0; localeIndex < numLocales; localeIndex++)
		{
		LmLocaleType testLocale;
		Err theErr = LmGetLocaleSetting(	localeIndex,
													lmChoiceLocale,
													&testLocale,
													sizeof(testLocale));
													
		ErrNonFatalDisplayIf(theErr, "Can\'t load locale");
		if	(	(testLocale.language == ((LmLocaleType*)&prefsLocale)->language)
			&&	(testLocale.country == ((LmLocaleType*)&prefsLocale)->country))
			{
			FormatsPreferences.localeIndex = localeIndex;
			}
		}

	// Allocate a handle for holding a list of the known locale indexes.
	tMemHandle = MemHandleNew(sizeof(*LocaleOrderP) * numLocales);
	ErrNonFatalDisplayIf(theErr, "Can\'t allocate sorted country list");
	LocaleOrderP = (UInt16 *)MemHandleLock(tMemHandle);
	ErrNonFatalDisplayIf(theErr, "Can\'t lock sorted country list");
	
	// Allocate a handle for holding a list of the country names, indexed by
	// locale index (i.e., NOT sorted).
	tMemHandle = MemHandleNew(sizeof(*LocaleCountryNamesP) * numLocales);
	ErrNonFatalDisplayIf(theErr, "Can\'t allocate country names list");
	LocaleCountryNamesP = (LocaleCountryNamesType)MemHandleLock(tMemHandle);
	ErrNonFatalDisplayIf(theErr, "Can\'t lock country names list");
	
	// Initialize both lists.
	//
	// DOLATER CS -	Make sure country names unique (append language code?)
	// 
	for (localeIndex = 0; localeIndex < numLocales; localeIndex++)
		{
		LocaleOrderP[localeIndex] = localeIndex;
		theErr = LmGetLocaleSetting(	localeIndex,
												lmChoiceCountryName,
												LocaleCountryNamesP[localeIndex],
												sizeof(LocaleCountryNamesP[localeIndex]));
		ErrNonFatalDisplayIf(theErr, "Error retrieving country name");
		}
	
	// Sort the list of known locales by country name.
	SysInsertionSort(	LocaleOrderP,
							numLocales,
							sizeof(*LocaleOrderP),
							CompareLocaleCountries,
							(Int32)LocaleCountryNamesP);

	return 0;		// no error
}

/***********************************************************************
 *
 * FUNCTION:    StopApplication
 *
 * DESCRIPTION: Save the preferences which may have changed.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	6/4/96	Initial Revision
 *			CS		07/16/99	Set prefDaylightSavings & prefMinutesWestOfGMT
 *								even though we don't allow user to modify them
 *								directly, since they should track country
 *								changes as well.
 *			CS		05/02/00	Rewrote to use LocaleOrderP list of sorted locale
 *								indexes.
 *			CS		05/16/00	LmCountryType/LmLanguageType are now back to
 *								CountryType/LanguageType.
 *			CS		07/28/00	Tossed daylightSavings & minutesWestOfGMT,
 *								since these guys are now controlled via
 *								a separate interface and no longer track
 *								country switches.
 *			CS		08/01/00	Set new preferences locale (instead of just
 *								country).
 *
 ***********************************************************************/
static void StopApplication (FormatsPreferencesType *formatsPreferencesP, Boolean isSubLaunched )
{
	LmLocaleType prefsLocale;
	Err theErr = errNone;
	
	if (!isSubLaunched)
		{
		FrmCloseAllForms ();

		if (panelIDsP)
			MemPtrFree(panelIDsP);
		
		// Toss list of sorted locale indexes and the list of country names
		if (LocaleOrderP)
			MemHandleFree(MemPtrRecoverHandle(LocaleOrderP));
		LocaleOrderP = NULL;
		if (LocaleCountryNamesP)
			MemHandleFree(MemPtrRecoverHandle(LocaleCountryNamesP));
		LocaleCountryNamesP = NULL;
		}
	// Write the system preferences that this panel allows changing
	PrefSetPreference(prefTimeFormat, formatsPreferencesP->timeFormat);
	PrefSetPreference(prefDateFormat, formatsPreferencesP->dateFormat);
	PrefSetPreference(prefLongDateFormat, formatsPreferencesP->longDateFormat);
	PrefSetPreference(prefWeekStartDay, formatsPreferencesP->weekStartDay);
	PrefSetPreference(prefNumberFormat, formatsPreferencesP->numberFormat);
	PrefSetPreference(prefMeasurementSystem, formatsPreferencesP->measurementSystem);
	

	// Get the country for the selected locale index and write it to preferences
	theErr = LmGetLocaleSetting(	formatsPreferencesP->localeIndex,
											lmChoiceLocale,
											&prefsLocale,
											sizeof(prefsLocale));
	ErrNonFatalDisplayIf(theErr, "Can\'t get locale");
	PrefSetPreference(prefLocale, *(UInt32 *)&prefsLocale);

}


/***********************************************************************
 *
 * FUNCTION:    MapToPositionWord
 *
 * DESCRIPTION:	Map a value to it's position in an array.  If the passed
 *						value is not found in the mappings array, a default
 *						mappings item will be returned.
 *
 * PARAMETERS:  value	- value to look for
 *
 * RETURNED:    position value found in
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	6/28/95	Initial Revision
 *
 ***********************************************************************/
extern UInt16 MapToPositionWord (UInt16 *mappingArray, UInt16 value,
										 UInt16 mappings, UInt16 defaultItem)
{
	UInt16 i;
	
	i = 0;
	while (mappingArray[i] != value && i < mappings)
		i++;
	if (i >= mappings)
		return defaultItem;

	return i;
}


/***********************************************************************
 *
 * FUNCTION:    MapToPosition
 *
 * DESCRIPTION:	Map a value to it's position in an array.  If the passed
 *						value is not found in the mappings array, a default
 *						mappings item will be returned.
 *
 * PARAMETERS:  value	- value to look for
 *
 * RETURNED:    position value found in
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	9/13/95	Initial Revision
 *
 ***********************************************************************/
static UInt16 MapToPosition (UInt8 *mappingArray, UInt8 value,
									UInt16 mappings, UInt16 defaultItem)
{
	UInt16 i;
	
	i = 0;
	while (mappingArray[i] != value && i < mappings)
		i++;
	if (i >= mappings)
		return defaultItem;

	return i;
}


/***********************************************************************
 *
 * FUNCTION:    PanelPickListDrawItem
 *
 * DEShortcutRIPTION: Draw a navigation list item.
 *
 * PARAMETERS:  itemNum - which shortcut to draw
 *					 bounds - bounds in which to draw the shortcut
 *					 unusedP - pointer to data (not used)
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger 5/29/96	Initial Revision
 *
 ***********************************************************************/

static void PanelPickListDrawItem (Int16 itemNum, RectanglePtr bounds, 
	Char ** UNUSED_PARAM(unusedP))
{
	Char * itemText;
	
	
	itemText = panelIDsP[itemNum].name;
	WinDrawChars(itemText, StrLen(itemText), bounds->topLeft.x, bounds->topLeft.y);
}


/***********************************************************************
 *
 * FUNCTION:    CreatePanelPickList
 *
 * DESCRIPTION: Create a list of panels available and select the current one.
 *
 * PARAMETERS:  listP - the list to contain the panel list
 *
 * RETURNED:    panelCount, panelIDsH, and panelIDsP are set
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	5/30/96	Initial Revision
 *
 ***********************************************************************/
static void CreatePanelPickList (ControlPtr triggerP, ListPtr listP, 
	ListDrawDataFuncPtr func)
{
	UInt16 currentAppCardNo;
	LocalID currentAppDBID;
	int item;
	

	SysCreatePanelList(&panelCount, &panelIDsH);
	
	if (panelCount > 0)
		panelIDsP = MemHandleLock(panelIDsH);
	
	// Now set the list to hold the number of panels found.  There
	// is no array of text to use.
	LstSetListChoices(listP, NULL, panelCount);
	
	// Now resize the list to the number of panel found
	LstSetHeight (listP, panelCount);
		
	
	// Because there is no array of text to use, we need a function
	// to interpret the panelIDsP list and draw the list items.
	LstSetDrawFunction(listP, func);
	
	// Now we should select the item in the list which matches the 
	// current app.
	SysCurAppDatabase(&currentAppCardNo, &currentAppDBID);
	for (item = 0; item < panelCount; item++)
		{
		if (panelIDsP[item].dbID == currentAppDBID &&
			 panelIDsP[item].cardNo == currentAppCardNo)
			 {
			 LstSetSelection(listP, item);
			 CtlSetLabel(triggerP, panelIDsP[item].name);
			 break;
			 }
		}
}


/***********************************************************************
 *
 * FUNCTION:    MoveObject
 *
 * DESCRIPTION:	Move an object within a form by an offset.
 *
 * PARAMETERS:  frm - the form containing the object to move
 *				id - the id of the object to move
 *				deltaX - x distance to move
 *				deltaY - y distance to move
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf 2/28/97	Initial Revision
 *
 ***********************************************************************/
static void MoveObject(FormPtr frm, UInt16 id, Int16 deltaX, Int16 deltaY,
		Boolean redraw)
{
	UInt16 index;
	Int16 x;
	Int16 y;
	
	index = FrmGetObjectIndex(frm, id);
	
	FrmGetObjectPosition(frm, index, &x, &y);
	
	x += deltaX;
	y += deltaY;
	
	if (redraw) 
		FrmHideObject(frm, index);
		
	FrmSetObjectPosition(frm, index, x, y);
	
	if (redraw) 
		FrmShowObject(frm,index);
}	


/***********************************************************************
 *
 * FUNCTION:    SetPreferencesByLocale
 *
 * DESCRIPTION: Given a country set the other international preferences
 *
 * PARAMETERS:  	formatsPreferencesP - pointer to set format preferences
 *						localeIndex	- locale to choose set of preferences by
 *
 * RETURNED:    preferences are set to standard values for the country
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	6/30/95	Initial Revision
 *			CS		07/02/99	Change measurement system to match new country.
 *			CS		07/16/99	Change prefDaylightSavings & prefMinutesWestOfGMT
 *								even though we don't allow user to modify them
 *								directly, since they should track country
 *								changes as well.
 *			CS		05/02/00	Rewrote to use locale indexes and load locale
 *								defaults from new Locale Manager.
 *			CS		07/28/00	Tossed daylightSavings & minutesWestOfGMT,
 *								since these guys are now controlled via
 *								a separate interface and no longer track
 *								country switches.
 *			vivek 07/30/00 Removed globals being used in the function.
 *			gap	09/29/00	Write date format changes immediately like time format
 *								changes are written in the event that attention manager
 *								is displayed over formats panel
 *          samk  01/04/01  do similary for prefLongDateFormat as georg does for prefDateFormat
 *                              so clock popup will be in sync with formats panel (if u pop up
 *                              the clock after changing country but *before* exiting format)
 *
 ***********************************************************************/
static void SetPreferencesByLocale(FormatsPreferencesType* formatsPreferencesP, 
		UInt16 localeIndex)
{
	Err theErr = errNone;
	
	// Load the locale settings for the locale selected by the user into
	// our preferences record.
	theErr = LmGetLocaleSetting(	localeIndex,
											lmChoiceTimeFormat, 
											&formatsPreferencesP->timeFormat,
											sizeof(formatsPreferencesP->timeFormat));
	ErrNonFatalDisplayIf(theErr, "Can\'t get new locale\'s time format");
	
	theErr = LmGetLocaleSetting(	localeIndex,
											lmChoiceDateFormat, 
											&formatsPreferencesP->dateFormat,
											sizeof(formatsPreferencesP->dateFormat));
	ErrNonFatalDisplayIf(theErr, "Can\'t get new locale\'s date format");
	
	theErr = LmGetLocaleSetting(	localeIndex,
											lmChoiceLongDateFormat, 
											&formatsPreferencesP->longDateFormat,
											sizeof(formatsPreferencesP->longDateFormat));
	ErrNonFatalDisplayIf(theErr, "Can\'t get new locale\'s long date format");
	
	theErr = LmGetLocaleSetting(	localeIndex,
											lmChoiceWeekStartDay, 
											&formatsPreferencesP->weekStartDay,
											sizeof(formatsPreferencesP->weekStartDay));
	ErrNonFatalDisplayIf(theErr, "Can\'t get new locale\'s week start day");
	
	theErr = LmGetLocaleSetting(	localeIndex,
											lmChoiceNumberFormat, 
											&formatsPreferencesP->numberFormat,
											sizeof(formatsPreferencesP->numberFormat));
	ErrNonFatalDisplayIf(theErr, "Can\'t get new locale\'s number format");
	
	theErr = LmGetLocaleSetting(	localeIndex,
											lmChoiceMeasurementSystem, 
											&formatsPreferencesP->measurementSystem,
											sizeof(formatsPreferencesP->measurementSystem));
	ErrNonFatalDisplayIf(theErr, "Can\'t get new locale\'s measurement system");
	
	// Write out the time format change because the app launcher 
	// needs the latest value if it is activated.  This can't wait
	// until the app is exited.
	PrefSetPreference(prefTimeFormat, formatsPreferencesP->timeFormat);
	
	// Date format also needs to be written out immediately. Attention
	// manager may be brought up while format panel is open and
	// attention manager date/time display format should match user's 
	// most recent selection.
	PrefSetPreference(prefDateFormat, formatsPreferencesP->dateFormat);

	// ditto for prefLongDateFormat
	PrefSetPreference(prefLongDateFormat, formatsPreferencesP->longDateFormat);
}


/***********************************************************************
 *
 * FUNCTION:		RedrawStringIfDifferent
 *
 * DESCRIPTION:	If newString doesn't equal oldString then draw newString 
 * at x, y and replace oldString with newString.
 *
 * PARAMETERS:		oldString - the string already drawn on the screen
 *						newString - a new string to draw if different
 *						x, y - where the old string was drawn.
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	2/28/96	Initial version
 *
 ***********************************************************************/
static void RedrawStringIfDifferent (Char * oldString, Char * newString, Int16 x, Int16 y)
{
	RectangleType		r;
	Int16					oldWidth;
	Int16					newWidth;
	Int16					winWidth;
	Int16					winHeight;
	
	
	// Redraw the time string only if the new one is different.
	if (StrCompare(newString, oldString) != 0)
		{
		// Draw the new time string
		WinDrawChars (newString, StrLen (newString), x, y);
		
		//	Check if the old string was wider than the new string. If so
		// we must erase the portion not overwritten by the new string.
		newWidth = FntCharsWidth(newString, StrLen(newString));
		if (StrLen(oldString) > 0)
			oldWidth = FntCharsWidth(oldString, StrLen(oldString));
		else
			{
			// handle case where FormatsFormForceDrawForm emptied out old string
			// Assume the string could have extended to the edge of the window.
			WinGetWindowExtent(&winWidth, &winHeight);
			oldWidth = winWidth - x;
			}
		
		if (oldWidth > newWidth)
			{
			r.topLeft.x = x + newWidth;
			r.topLeft.y = y;
			r.extent.x = oldWidth - newWidth;
			r.extent.y = FntLineHeight();
			WinEraseRectangle (&r, 0);
			}
		
		// Remember the newTimeString.
		StrCopy(oldString, newString);
		}
}


/***********************************************************************
 *
 * FUNCTION:		FormatsFormUpdateTime
 *
 * DESCRIPTION:	Update the displayed time string using the current
 *						time format. Nothing is drawn if there is no change.
 *
 * PARAMETERS:		nothing
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	9/14/95	Initial version
 *
 ***********************************************************************/
static void FormatsFormUpdateTime (void)
{
	char					newTimeString[timeStringLength];
	DateTimeType 		today;
	
	
	// Get the time and form a string from it based on the timeFormat.
	TimSecondsToDateTime(TimGetSeconds(), &today);
	TimeToAscii(today.hour, today.minute, FormatsPreferences.timeFormat, 
		newTimeString);
	
	
	// Redraw the time string only if the new one is different.
	RedrawStringIfDifferent(FormatsFormTimeString, newTimeString, 
		timeDisplayXPos, timeDisplayYPos);
}

	
/***********************************************************************
 *
 * FUNCTION:		FormatsFormUpdateDate
 *
 * DESCRIPTION:	Update the displayed date strings using the current
 *						date formats.
 *
 * PARAMETERS:		nothing
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	9/14/95	Initial version
 *
 ***********************************************************************/
static void FormatsFormUpdateDate (void)
{
	char					newDateString[longDateStrLength];
	DateTimeType 		today;
	
	
	// Get the time and form a string from it based on the 'Int16' date format.
	TimSecondsToDateTime(TimGetSeconds(), &today);
	DateToAscii(today.month, today.day, today.year,
					FormatsPreferences.dateFormat, newDateString);
	
	// Redraw the date string only if the new one is different.
	RedrawStringIfDifferent(FormatsFormDateString, newDateString, 
		dateDisplayXPos, dateDisplayYPos);
	
	
	// Get the time and form a string from it based on the 'long' date format.
	DateToAscii(today.month, today.day, today.year,
				FormatsPreferences.longDateFormat, newDateString);

	// Redraw the date string only if the new one is different.
	RedrawStringIfDifferent(FormatsFormLongDateString, newDateString, 
		dateDisplayXPos, dateDisplayYPos + FntLineHeight() + 1);
	
}


/***********************************************************************
 *
 * FUNCTION:    CountryListDrawItem
 *
 * DEShortCutRIPTION: Draw a navigation list item.
 *
 * PARAMETERS:  itemNum - which menu item to draw
 *					 bounds - bounds in which to draw the item's country name
 *					 data - pointer to sorted list of locale indexes
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger 8/5/96	Initial Revision
 *			CS		05/02/00	Rewrote to use new LocaleOrderP & Locale Manager.
 *
 ***********************************************************************/

static void CountryListDrawItem (Int16 itemNum, RectanglePtr bounds, Char **data)
{
	UInt16* localeOrderP = (UInt16*)data;
	
	WinDrawChars(	LocaleCountryNamesP[localeOrderP[itemNum]],
						StrLen(LocaleCountryNamesP[localeOrderP[itemNum]]),
						bounds->topLeft.x,
						bounds->topLeft.y);
}


/***********************************************************************
 *
 * FUNCTION:    FormatsFormInit
 *
 * DESCRIPTION:	Initialize the ui in the formats view.  This means setting
 *						the ui to match the system preferences.
 *
 * PARAMETERS:  formP
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	9/12/95	Initial version
 *			CS		05/02/00	Rewrote countryList handling to use new
 *								LocaleOrderP & Locale Manager.
 *
 ***********************************************************************/
static void FormatsFormInit (FormPtr formP)
{
	ListPtr listP;
	UInt16 mappedValue;
	UInt16 doneButtonIndex;
	RectangleType r;
	UInt16 distance;
	UInt16 numLocales = LmGetNumLocales();
	ControlType *triggerP;				// the panel picklist trigger
	MemHandle nameResource;				// this panel's name resource (tAIN)

	// Configure the form differently if CalledFromAppMode
	if (CalledFromAppMode)
		{
		FrmHideObject(formP, FrmGetObjectIndex (formP, formatPanelPickTrigger));
		FrmShowObject(formP, FrmGetObjectIndex (formP, formatPanelNameLabel));
		
		// The Done button is supposed to be available for the user to return
		// to the calling app.
		doneButtonIndex = FrmGetObjectIndex (formP, formatsDoneButton);
		FrmShowObject(formP, doneButtonIndex);
		
		// Figure out how much space the Done button plus some separation requires.
		FrmGetObjectBounds(formP, doneButtonIndex, &r);
		distance = r.extent.x + ButtonSeparationXDistance;
		
		// Each button at the bottom of the display (besides the Done button)
		// should be moved over now that the Done button is shown.
		// Comment these lines in when buttons are added to the bottom of the form.
//		MoveObject(formP, FirstButton, distance, 0, false);
//		MoveObject(formP, SecondButton, distance, 0, false);
		}
	else
		{
		// The panel pick list is displayed - set the label to the name of the
		// current panel now so there is not a delay when the form appears.
		triggerP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, formatPanelPickTrigger));
		nameResource = DmGetResource(ainRsc, ainID);
		ErrNonFatalDisplayIf(nameResource == NULL, "panel's name resource not found");
		CtlSetLabel(triggerP, (char *)MemHandleLock(nameResource));
		MemHandleUnlock(nameResource);
		}
	
	
	// Set the country trigger and list
	listP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, countryList));
	LstSetListChoices(listP, (Char **) LocaleOrderP, numLocales);
	LstSetHeight (listP, numLocales);
	LstSetDrawFunction(listP, CountryListDrawItem);
	mappedValue = MapToPositionWord(	LocaleOrderP,
												FormatsPreferences.localeIndex,
												numLocales,
												0);
	LstSetSelection(listP, mappedValue);
	LstMakeItemVisible(listP, mappedValue);
	CtlSetLabel(FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, countryTrigger)),
		LocaleCountryNamesP[LocaleOrderP[mappedValue]]);

	// Set the time format trigger and list
	listP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, timeFormatList));
	mappedValue = MapToPosition ((UInt8 *) TimeFormatMappings,
										  FormatsPreferences.timeFormat,
										  timeFormatsSelectable,
										  defaultTimeFormatItem);
	LstSetSelection(listP, mappedValue);
	CtlSetLabel(FrmGetObjectPtr (formP,
										  FrmGetObjectIndex (formP, timeFormatTrigger)),
					LstGetSelectionText(listP, mappedValue));


	// Set the date format trigger and list
	listP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, dateFormatList));
	mappedValue = MapToPosition ((UInt8 *) DateFormatMappings,
										  FormatsPreferences.dateFormat,
										  dateFormatsSelectable,
										  defaultDateFormatItem);
	LstSetSelection(listP, mappedValue);
	CtlSetLabel(FrmGetObjectPtr (formP,
										  FrmGetObjectIndex (formP, dateFormatTrigger)),
					LstGetSelectionText(listP, mappedValue));

	//	Set the 'week starts' trigger & list
	listP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, weekStartList));
	LstSetSelection(listP, FormatsPreferences.weekStartDay);
	CtlSetLabel(FrmGetObjectPtr (formP,
										  FrmGetObjectIndex (formP, weekStartTrigger)),
					LstGetSelectionText(listP, FormatsPreferences.weekStartDay));

	// Set the number trigger and list
	listP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, numberFormatList));
	LstSetSelection(listP, FormatsPreferences.numberFormat);
	CtlSetLabel(FrmGetObjectPtr (formP,
										  FrmGetObjectIndex (formP, numberFormatTrigger)),
					LstGetSelectionText(listP, FormatsPreferences.numberFormat));

}


/***********************************************************************
 *
 * FUNCTION:		FormatsFormDrawForm
 *
 * DESCRIPTION:	Draw the non-resource parts of the Formats form of the
 *						preferences app.
 *
 * PARAMETERS:		nothing
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	9/12/95	Initial version
 *
 ***********************************************************************/

static void FormatsFormDrawForm (void)
{
	Int16 formWidth;
	
	
	WinGetWindowExtent(&formWidth, NULL);
	WinDrawLine (0, formatsSepLineYPos, formWidth, formatsSepLineYPos);

	FormatsFormUpdateTime ();
	FormatsFormUpdateDate ();
}


/***********************************************************************
 *
 * FUNCTION:		FormatsFormForceDrawForm
 *
 * DESCRIPTION:	Draw the non-resource parts of the Formats form of the
 *						preferences app even if they don't appear different.
 *
 * PARAMETERS:		nothing
 *
 * RETURNED:		nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	9/12/95	Initial version
 *
 ***********************************************************************/

static void FormatsFormForceDrawForm (void)
{
	FormatsFormTimeString[0] = nullChr;	// dirty the string so it's updated
	FormatsFormDateString[0] = nullChr;	// dirty the string so it's updated
	FormatsFormLongDateString[0] = nullChr;	// dirty the string so it's updated
	FormatsFormDrawForm ();
}


/***********************************************************************
 *
 * FUNCTION:    FormatsFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the Formats form
 *              of the Preferences application.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has been handled and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			kcr	9/11/95	Initial version
 *			roger	6/4/96	Added panel pick list
 *			CS		05/02/00	Rewrote countryList handling to use new
 *								LocaleOrderP & Locale Manager.
 *			CS		08/15/00	Initialize new event structure.
 *			gap	09/29/00	Write date format changes immediately like time format
 *								changes are written in the event that attention manager
 *								is displayed over formats panel
 *			samk	01/10/01	write out longDateFormat too
 *
 ***********************************************************************/
static Boolean FormatsFormHandleEvent (EventType * event)
{
	FormPtr 			formP;
	Boolean 			handled = false;
	UInt16	 		currentAppCardNo;
	LocalID			currentAppDBID;
	EventType		newEvent;


	if (event->eType == nilEvent)
		{
		FormatsFormUpdateTime ();
		FormatsFormUpdateDate ();
		
		return true;				// handled
		}
	
	else if (event->eType == ctlSelectEvent)
		{
		switch (event->data.ctlSelect.controlID)
			{
			case formatsDoneButton:
				// By simply exiting we return to the prior which called us.
				MemSet(&newEvent, sizeof(newEvent), 0);	// Initialize new event structure
				newEvent.eType = appStopEvent;
				EvtAddEventToQueue(&newEvent);
				handled = true;
				break;
			}
		}

	if (event->eType == popSelectEvent)
		{
		switch (event->data.popSelect.listID)
			{
			case formatPanelPickList:
				// Switch to the panel if it isn't this one
				SysCurAppDatabase(&currentAppCardNo, &currentAppDBID);
				if (panelIDsP[event->data.popSelect.selection].dbID != currentAppDBID ||
					 panelIDsP[event->data.popSelect.selection].cardNo != currentAppCardNo)
					{
					SysUIAppSwitch(panelIDsP[event->data.popSelect.selection].cardNo, 
						panelIDsP[event->data.popSelect.selection].dbID, 
						sysAppLaunchCmdNormalLaunch, 0);
					}
				
				handled = true;
				break;
				
			case countryList:
				//	Do nothing if setting hasn't changed
				if (FormatsPreferences.localeIndex !=
									LocaleOrderP[event->data.popSelect.selection])
					{
					FormatsPreferences.localeIndex =
									LocaleOrderP[event->data.popSelect.selection];
					SetPreferencesByLocale(&FormatsPreferences, LocaleOrderP[event->data.popSelect.selection]);
					formP = FrmGetActiveForm ();
					FormatsFormInit(formP);			//	Re-display new values
					FormatsFormForceDrawForm ();
					}
				handled = true;
				break;

			case timeFormatList:
				//	Do nothing if setting hasn't changed:
				if (FormatsPreferences.timeFormat !=
								TimeFormatMappings[event->data.popSelect.selection])
					{
					FormatsPreferences.timeFormat =
								TimeFormatMappings[event->data.popSelect.selection];
					FormatsFormUpdateTime ();
					
					// Write out the time format change because the app launcher 
					//  needs the latest value if it is activated.
					PrefSetPreference(prefTimeFormat, FormatsPreferences.timeFormat);
					}
				// leave handled false so that the trigger is updated
				break;
				
			case dateFormatList:
				//	Do nothing if setting hasn't changed:
				if (FormatsPreferences.dateFormat !=
								DateFormatMappings[event->data.popSelect.selection])
					{
					FormatsPreferences.dateFormat =
								DateFormatMappings[event->data.popSelect.selection];
					FormatsPreferences.longDateFormat =
								LongDateFormatMappings[event->data.popSelect.selection];
					FormatsFormUpdateDate ();

					// Date format needs to be written out immediately. Attention
					// manager may be brought up while format panel is open and
					// attention manager date/time display format should match user's 
					// most recent selection.
					PrefSetPreference(prefDateFormat, FormatsPreferences.dateFormat);

					// ditto for prefLongDateFormat -- clock needs it
					PrefSetPreference(prefLongDateFormat, FormatsPreferences.longDateFormat);
					}
				// leave handled false so that the trigger is updated
				break;

			case weekStartList:
				FormatsPreferences.weekStartDay =
												(UInt8) event->data.popSelect.selection;
				break;

			case numberFormatList:
				FormatsPreferences.numberFormat =
								(NumberFormatType) event->data.popSelect.selection;
				// leave handled false so that the trigger is updated
				break;
			}
		}

	else if (event->eType == frmOpenEvent)
		{
		formP = FrmGetActiveForm ();
		FormatsFormInit (formP);
		FrmDrawForm (formP);
		FormatsFormForceDrawForm ();


		// Now that the form is displayed, generate the panel pick list.
		// By occuring here after everything is displayed the time required
		// isn't noticed by the user.
		if (!CalledFromAppMode)
			{
			CreatePanelPickList(
				FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, formatPanelPickTrigger)),
				FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, formatPanelPickList)),
				PanelPickListDrawItem);
			}


		handled = true;
		}
	
	else if (event->eType == frmUpdateEvent)
		{
		formP = FrmGetActiveForm ();
		FrmDrawForm(formP);
		FormatsFormForceDrawForm();
		handled = true;
		}

	return (handled);
}

	
/***********************************************************************
 *
 * FUNCTION:    ApplicationHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and sets the 
 *						event handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has MemHandle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *			Name	Date			Description
 *			----	----			-----------
 *			art	2/21/95		Initial Revision
 *			kcr	9/11/95		added formats form
 *			kcr	9/22/95		converted from CurrentFormHandleEvent
 *
 ***********************************************************************/
static Boolean ApplicationHandleEvent (EventType * event)
{
	FormPtr formP;
	UInt16 formId;

	if (event->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = event->data.frmLoad.formID;
		formP = FrmInitForm (formId);
		FrmSetActiveForm (formP);		
		
		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmDispatchEvent each time it receives an
		// event.
		switch (formId)
			{
			case formatsForm:
				FrmSetEventHandler (formP, FormatsFormHandleEvent);
				break;
			}
		return (true);
		}
		
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:    EventLoop
 *
 * DESCRIPTION: This routine is the event loop for the Preferences
 *              aplication.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	2/21/95	Initial Revision
 *			kcr	9/22/95	converted from CurrentFormHandleEvent to
 *								ApplicationHandleEvent
 *			kcr	9/27/95	update time/date display periodically
 *
 ***********************************************************************/
static void EventLoop (void)
{
	EventType event;

	do
		{
		// Wait no more than one second.  If more than one second passes 
		// a nilEvent will appear.  When this happpens, update the time.
		EvtGetEvent (&event, sysTicksPerSecond);

		if (! SysHandleEvent (&event))
			if (! ApplicationHandleEvent (&event))
					FrmDispatchEvent (&event);
		}
		while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the Formats Preference
 * Panel.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	2/21/95	Initial Revision
 *			roger	5/28/95	Broke out from the Preference app into it's own panel
 *			roger	1/9/97	Perform sysAppLaunchCmdSetActivePanel
 *			vivek	7/30/00	Perform sysAppLaunchCmdLocaleChanging
 *
 ***********************************************************************/
UInt32		PilotMain(UInt16 cmd, void * cmdPBP, UInt16 UNUSED_PARAM(launchFlags))
{
	UInt16 error;
	FormatsPreferencesType stackFormatsPreferences;
	FormatsPreferencesType* formatsPrefsP;
	Boolean isSubLaunched = false;
	
	// We don't support any action codes
	if (cmd != sysAppLaunchCmdNormalLaunch &&
		cmd != sysAppLaunchCmdPanelCalledFromApp &&
		cmd != sysAppLaunchCmdReturnFromPanel &&
		cmd != sysAppLaunchCmdSystemReset &&
		cmd != sysAppLaunchCmdNotify) 
		{
		return sysErrParamErr;
		}

	if (cmd == sysAppLaunchCmdSystemReset)
		{
		RegisterLocaleChangingNotification();
		return 0;
		}
	else if (cmd == sysAppLaunchCmdNotify)
		{
			SysNotifyParamType* notifyP = (SysNotifyParamType*)cmdPBP;
			if (notifyP->notifyType == sysNotifyLocaleChangedEvent)
				{				
				isSubLaunched = true;
				formatsPrefsP = &stackFormatsPreferences;
				LmLocaleToIndex(&((SysNotifyLocaleChangedType *)(notifyP->notifyDetailsP))->newLocale, &formatsPrefsP->localeIndex);
				HandleLocaleChangedNotification(formatsPrefsP);
				}
		}
	else
		{
		CalledFromAppMode = (cmd == sysAppLaunchCmdPanelCalledFromApp);
		
	#if EMULATION_LEVEL == EMULATION_NONE
		if (!CalledFromAppMode)
			{
			PrefActivePanelParamsType prefs;
			
			// set this panel as the active one next time the prefs app is opened
			prefs.activePanel = sysFileCFormats;
			AppCallWithCommand(sysFileCPreferences, prefAppLaunchCmdSetActivePanel, &prefs);
			}
	#endif

		error = StartApplication ();

		FrmGotoForm (formatsForm);

		if (! error)
			EventLoop ();
			formatsPrefsP = &FormatsPreferences;
		}
		
	StopApplication (formatsPrefsP, isSubLaunched);
	return 0;
}
