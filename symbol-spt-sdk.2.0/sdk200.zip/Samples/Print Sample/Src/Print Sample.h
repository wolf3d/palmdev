#pragma once

VoidPtr	GetObjectPtr( Word objectID );
