CodeWarrior for Palm OS Release 5
Project Stationery
July 20, 1998
===================================

The requirement that all applications be created from the PalmPilot WinSDK folder
are no longer necessary.  All projects are created with paths relative to the 
"PalmOS 3.0 Support" folder or the users' project folder.

If you have not already done so, it is strongly recommended that you run through
the Palm OS Tutorial, found in the CodeWarrior Documentation folder.  This 
tutorial guides you step by step through all the steps necessary to write a Palm
OS program.

Please feel free to send us any suggestions, complaints, bug reports, and gripes.
Fill out the bug report form, located in the release notes folder, and email
it to:

codewarrior@palm.com

===================================
Metrowerks Palm OS Team
