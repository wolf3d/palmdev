/* wrapper for the native stdarg */
#include <stdarg.h>
